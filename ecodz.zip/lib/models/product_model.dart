class ProductModel {
  final String id;
  final String traderId;
  final String? categoryId;
  final String name;
  final String? description;
  final double price;
  final int discountPercent;
  final int stockQuantity;
  final List<String> images;
  final bool isAvailable;
  final Map<String, dynamic> specifications;
  final DateTime createdAt;
  final DateTime updatedAt;
  
  // Joined fields
  final String? traderCompanyName;
  final double? traderRating;
  final String? categoryName;
  final double? averageRating;
  final int? reviewCount;

  ProductModel({
    required this.id,
    required this.traderId,
    this.categoryId,
    required this.name,
    this.description,
    required this.price,
    this.discountPercent = 0,
    this.stockQuantity = 0,
    this.images = const [],
    this.isAvailable = true,
    this.specifications = const {},
    required this.createdAt,
    required this.updatedAt,
    this.traderCompanyName,
    this.traderRating,
    this.categoryName,
    this.averageRating,
    this.reviewCount,
  });

  factory ProductModel.fromJson(Map<String, dynamic> json) {
    // Calculate average rating if reviews exist
    double? avgRating;
    int? reviewCount;
    if (json['reviews'] != null && (json['reviews'] as List).isNotEmpty) {
      final reviews = json['reviews'] as List;
      reviewCount = reviews.length;
      avgRating = reviews
          .map((r) => (r['rating'] as num).toDouble())
          .reduce((a, b) => a + b) / reviews.length;
    }

    return ProductModel(
      id: json['id'],
      traderId: json['trader_id'],
      categoryId: json['category_id'],
      name: json['name'],
      description: json['description'],
      price: double.parse(json['price'].toString()),
      discountPercent: json['discount_percent'] ?? 0,
      stockQuantity: json['stock_quantity'] ?? 0,
      images: json['images'] != null ? List<String>.from(json['images']) : [],
      isAvailable: json['is_available'] ?? true,
      specifications: json['specifications'] ?? {},
      createdAt: DateTime.parse(json['created_at']),
      updatedAt: DateTime.parse(json['updated_at']),
      traderCompanyName: json['traders']?['company_name'],
      traderRating: json['traders']?['rating'] != null
          ? double.parse(json['traders']['rating'].toString())
          : null,
      categoryName: json['categories']?['name_ar'],
      averageRating: avgRating,
      reviewCount: reviewCount,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'trader_id': traderId,
      'category_id': categoryId,
      'name': name,
      'description': description,
      'price': price,
      'discount_percent': discountPercent,
      'stock_quantity': stockQuantity,
      'images': images,
      'is_available': isAvailable,
      'specifications': specifications,
      'created_at': createdAt.toIso8601String(),
      'updated_at': updatedAt.toIso8601String(),
    };
  }

  // Computed properties
  double get discountedPrice {
    if (discountPercent > 0) {
      return price * (1 - discountPercent / 100);
    }
    return price;
  }
  
  bool get hasDiscount => discountPercent > 0;
  bool get inStock => stockQuantity > 0;
  bool get lowStock => stockQuantity > 0 && stockQuantity <= 5;
  
  String get stockStatus {
    if (!inStock) return 'غير متوفر';
    if (lowStock) return 'كمية محدودة';
    return 'متوفر';
  }
  
  String get priceFormatted {
    return '${price.toStringAsFixed(2)} د.ج';
  }
  
  String get discountedPriceFormatted {
    return '${discountedPrice.toStringAsFixed(2)} د.ج';
  }
  
  String get mainImage {
    return images.isNotEmpty ? images.first : '';
  }
}