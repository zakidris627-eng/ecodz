class OrderModel {
  final String id;
  final String? customerId;
  final String orderNumber;
  final String status;
  final double totalAmount;
  final double commissionAmount;
  final Map<String, dynamic>? shippingAddress;
  final String? paymentMethod;
  final String paymentStatus;
  final String? notes;
  final DateTime createdAt;
  final DateTime updatedAt;
  final List<OrderItemModel>? items;

  OrderModel({
    required this.id,
    this.customerId,
    required this.orderNumber,
    this.status = 'pending',
    required this.totalAmount,
    required this.commissionAmount,
    this.shippingAddress,
    this.paymentMethod,
    this.paymentStatus = 'pending',
    this.notes,
    required this.createdAt,
    required this.updatedAt,
    this.items,
  });

  factory OrderModel.fromJson(Map<String, dynamic> json) {
    return OrderModel(
      id: json['id'],
      customerId: json['customer_id'],
      orderNumber: json['order_number'],
      status: json['status'] ?? 'pending',
      totalAmount: double.parse(json['total_amount'].toString()),
      commissionAmount: double.parse(json['commission_amount'].toString()),
      shippingAddress: json['shipping_address'],
      paymentMethod: json['payment_method'],
      paymentStatus: json['payment_status'] ?? 'pending',
      notes: json['notes'],
      createdAt: DateTime.parse(json['created_at']),
      updatedAt: DateTime.parse(json['updated_at']),
      items: json['order_items'] != null
          ? (json['order_items'] as List)
              .map((item) => OrderItemModel.fromJson(item))
              .toList()
          : null,
    );
  }

  String get statusArabic {
    switch (status) {
      case 'pending':
        return 'قيد الانتظار';
      case 'confirmed':
        return 'مؤكد';
      case 'processing':
        return 'قيد المعالجة';
      case 'shipped':
        return 'تم الشحن';
      case 'delivered':
        return 'تم التوصيل';
      case 'cancelled':
        return 'ملغي';
      case 'returned':
        return 'مرتجع';
      default:
        return status;
    }
  }
  
  String get paymentStatusArabic {
    switch (paymentStatus) {
      case 'pending':
        return 'قيد الانتظار';
      case 'paid':
        return 'تم الدفع';
      case 'failed':
        return 'فشل';
      case 'refunded':
        return 'مسترجع';
      default:
        return paymentStatus;
    }
  }
  
  String get totalAmountFormatted {
    return '${totalAmount.toStringAsFixed(2)} د.ج';
  }
  
  int get totalItems {
    if (items == null) return 0;
    return items!.fold(0, (sum, item) => sum + item.quantity);
  }
}

class OrderItemModel {
  final String id;
  final String orderId;
  final String? productId;
  final int quantity;
  final double unitPrice;
  final double totalPrice;
  final double commissionRate;

  OrderItemModel({
    required this.id,
    required this.orderId,
    this.productId,
    required this.quantity,
    required this.unitPrice,
    required this.totalPrice,
    required this.commissionRate,
  });

  factory OrderItemModel.fromJson(Map<String, dynamic> json) {
    return OrderItemModel(
      id: json['id'],
      orderId: json['order_id'],
      productId: json['product_id'],
      quantity: json['quantity'],
      unitPrice: double.parse(json['unit_price'].toString()),
      totalPrice: double.parse(json['total_price'].toString()),
      commissionRate: double.parse(json['commission_rate'].toString()),
    );
  }
  
  String get unitPriceFormatted {
    return '${unitPrice.toStringAsFixed(2)} د.ج';
  }
  
  String get totalPriceFormatted {
    return '${totalPrice.toStringAsFixed(2)} د.ج';
  }
}