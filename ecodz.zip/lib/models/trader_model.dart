class TraderModel {
  final String id;
  final String userId;
  final String companyName;
  final String? commercialRegistration;
  final String? taxNumber;
  final String businessType;
  final String? description;
  final String status;
  final List<Map<String, dynamic>> verificationDocuments;
  final String? rejectionReason;
  final double rating;
  final int totalSales;
  final DateTime createdAt;
  final DateTime updatedAt;
  
  // Joined fields
  final String? userEmail;
  final String? userPhone;
  final String? userFullName;

  TraderModel({
    required this.id,
    required this.userId,
    required this.companyName,
    this.commercialRegistration,
    this.taxNumber,
    required this.businessType,
    this.description,
    this.status = 'pending',
    this.verificationDocuments = const [],
    this.rejectionReason,
    this.rating = 0,
    this.totalSales = 0,
    required this.createdAt,
    required this.updatedAt,
    this.userEmail,
    this.userPhone,
    this.userFullName,
  });

  factory TraderModel.fromJson(Map<String, dynamic> json) {
    return TraderModel(
      id: json['id'],
      userId: json['user_id'],
      companyName: json['company_name'],
      commercialRegistration: json['commercial_registration'],
      taxNumber: json['tax_number'],
      businessType: json['business_type'],
      description: json['description'],
      status: json['status'] ?? 'pending',
      verificationDocuments: json['verification_documents'] != null
          ? List<Map<String, dynamic>>.from(json['verification_documents'])
          : [],
      rejectionReason: json['rejection_reason'],
      rating: double.parse((json['rating'] ?? 0).toString()),
      totalSales: json['total_sales'] ?? 0,
      createdAt: DateTime.parse(json['created_at']),
      updatedAt: DateTime.parse(json['updated_at']),
      userEmail: json['users']?['email'],
      userPhone: json['users']?['phone'],
      userFullName: json['users']?['full_name'],
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'user_id': userId,
      'company_name': companyName,
      'commercial_registration': commercialRegistration,
      'tax_number': taxNumber,
      'business_type': businessType,
      'description': description,
      'status': status,
      'verification_documents': verificationDocuments,
      'rejection_reason': rejectionReason,
      'rating': rating,
      'total_sales': totalSales,
      'created_at': createdAt.toIso8601String(),
      'updated_at': updatedAt.toIso8601String(),
    };
  }

  // Status helpers
  bool get isPending => status == 'pending';
  bool get isApproved => status == 'approved';
  bool get isRejected => status == 'rejected';
  bool get isSuspended => status == 'suspended';
  
  String get statusArabic {
    switch (status) {
      case 'pending':
        return 'قيد المراجعة';
      case 'approved':
        return 'مقبول';
      case 'rejected':
        return 'مرفوض';
      case 'suspended':
        return 'موقوف';
      default:
        return status;
    }
  }
  
  String get businessTypeArabic {
    switch (businessType) {
      case 'retail':
        return 'تجزئة';
      case 'wholesale':
        return 'جملة';
      case 'manufacturing':
        return 'تصنيع';
      case 'service':
        return 'خدمات';
      default:
        return businessType;
    }
  }
}