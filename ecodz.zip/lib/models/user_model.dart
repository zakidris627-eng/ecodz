class UserModel {
  final String id;
  final String email;
  final String? phone;
  final String fullName;
  final String userType;
  final String? avatarUrl;
  final bool isVerified;
  final DateTime createdAt;
  final DateTime updatedAt;

  UserModel({
    required this.id,
    required this.email,
    this.phone,
    required this.fullName,
    required this.userType,
    this.avatarUrl,
    this.isVerified = false,
    required this.createdAt,
    required this.updatedAt,
  });

  factory UserModel.fromJson(Map<String, dynamic> json) {
    return UserModel(
      id: json['id'],
      email: json['email'],
      phone: json['phone'],
      fullName: json['full_name'],
      userType: json['user_type'],
      avatarUrl: json['avatar_url'],
      isVerified: json['is_verified'] ?? false,
      createdAt: DateTime.parse(json['created_at']),
      updatedAt: DateTime.parse(json['updated_at']),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'email': email,
      'phone': phone,
      'full_name': fullName,
      'user_type': userType,
      'avatar_url': avatarUrl,
      'is_verified': isVerified,
      'created_at': createdAt.toIso8601String(),
      'updated_at': updatedAt.toIso8601String(),
    };
  }

  // Helper getters
  bool get isAdmin => userType == 'admin';
  bool get isTrader => userType == 'trader';
  bool get isCustomer => userType == 'customer';
  
  String get userTypeArabic {
    switch (userType) {
      case 'admin':
        return 'مدير';
      case 'trader':
        return 'تاجر';
      case 'customer':
        return 'زبون';
      default:
        return 'مستخدم';
    }
  }
  
  String get initials {
    final names = fullName.split(' ');
    if (names.length >= 2) {
      return '${names[0][0]}${names[1][0]}'.toUpperCase();
    }
    return fullName[0].toUpperCase();
  }
}