import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:go_router/go_router.dart';
import '../../providers/auth_provider.dart';
import '../../providers/product_provider.dart';
import '../../widgets/customer/product_grid_card.dart';

class CustomerHomeScreen extends StatefulWidget {
  final String? searchQuery;
  final String? category;
  const CustomerHomeScreen({super.key, this.searchQuery, this.category});
  @override
  State<CustomerHomeScreen> createState() => _CustomerHomeScreenState();
}

class _CustomerHomeScreenState extends State<CustomerHomeScreen> {
  final _searchController = TextEditingController();
  @override
  void initState() {
    super.initState();
    _loadData();
    if (widget.searchQuery != null) _searchController.text = widget.searchQuery!;
  }
  Future<void> _loadData() async => context.read<ProductProvider>().loadAvailableProducts();
  @override
  void dispose() { _searchController.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('ecodz'),
        actions: [
          IconButton(icon: const Icon(Icons.notifications), onPressed: () => context.push('/customer/notifications')),
          IconButton(icon: const Icon(Icons.shopping_cart), onPressed: () => context.push('/customer/cart')),
        ],
      ),
      drawer: Drawer(child: ListView(padding: EdgeInsets.zero, children: [
        DrawerHeader(decoration: BoxDecoration(color: Theme.of(context).primaryColor), child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisAlignment: MainAxisAlignment.end, children: [
          CircleAvatar(radius: 30, backgroundColor: Colors.white, child: Icon(Icons.person, color: Theme.of(context).primaryColor)),
          const SizedBox(height: 10),
          Text(context.watch<AuthProvider>().currentUser?.fullName ?? 'زبون', style: const TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold)),
        ])),
        ListTile(leading: const Icon(Icons.home), title: const Text('الرئيسية'), onTap: () => Navigator.pop(context)),
        ListTile(leading: const Icon(Icons.shopping_bag), title: const Text('طلباتي'), onTap: () { Navigator.pop(context); context.push('/customer/orders'); }),
        const Divider(),
        ListTile(leading: const Icon(Icons.logout, color: Colors.red), title: const Text('تسجيل الخروج', style: TextStyle(color: Colors.red)), onTap: () async { await context.read<AuthProvider>().signOut(); if (mounted) context.go('/login'); }),
      ])),
      body: Column(children: [
        Padding(padding: const EdgeInsets.all(16), child: TextField(
          controller: _searchController,
          decoration: InputDecoration(hintText: 'ابحث عن منتج...', prefixIcon: const Icon(Icons.search), border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)), filled: true, fillColor: Colors.grey[100]),
          onSubmitted: (value) => context.push('/customer/search?q=$value'),
        )),
        Expanded(child: RefreshIndicator(
          onRefresh: _loadData,
          child: Consumer<ProductProvider>(
            builder: (context, productProvider, child) {
              if (productProvider.isLoading) return const Center(child: CircularProgressIndicator());
              if (productProvider.availableProducts.isEmpty) return const Center(child: Text('لا توجد منتجات'));
              return GridView.builder(
                padding: const EdgeInsets.all(16),
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2, crossAxisSpacing: 10, mainAxisSpacing: 10, childAspectRatio: 0.7),
                itemCount: productProvider.availableProducts.length,
                itemBuilder: (context, index) => ProductGridCard(product: productProvider.availableProducts[index]),
              );
            },
          ),
        )),
      ]),
    );
  }
}