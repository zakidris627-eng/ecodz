import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../providers/trader_provider.dart';
import '../../models/trader_model.dart';

class TradersManagementScreen extends StatefulWidget {
  final String? initialFilter;
  const TradersManagementScreen({super.key, this.initialFilter});
  @override
  State<TradersManagementScreen> createState() => _TradersManagementScreenState();
}

class _TradersManagementScreenState extends State<TradersManagementScreen> {
  String _selectedFilter = 'all';

  @override
  void initState() {
    super.initState();
    if (widget.initialFilter != null) _selectedFilter = widget.initialFilter!;
    context.read<TraderProvider>().loadAllTraders();
  }

  List<TraderModel> _filterTraders(List<TraderModel> traders) {
    switch (_selectedFilter) {
      case 'pending': return traders.where((t) => t.isPending).toList();
      case 'approved': return traders.where((t) => t.isApproved).toList();
      case 'rejected': return traders.where((t) => t.isRejected).toList();
      case 'suspended': return traders.where((t) => t.isSuspended).toList();
      default: return traders;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('إدارة التجار')),
      body: Column(
        children: [
          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.all(12),
            child: Row(children: [
              _buildFilterChip('الكل', 'all'),
              const SizedBox(width: 8),
              _buildFilterChip('معلق', 'pending', Colors.orange),
              const SizedBox(width: 8),
              _buildFilterChip('مقبول', 'approved', Colors.green),
              const SizedBox(width: 8),
              _buildFilterChip('مرفوض', 'rejected', Colors.red),
              const SizedBox(width: 8),
              _buildFilterChip('موقوف', 'suspended', Colors.grey),
            ]),
          ),
          Expanded(
            child: Consumer<TraderProvider>(
              builder: (context, traderProvider, child) {
                if (traderProvider.isLoading) return const Center(child: CircularProgressIndicator());
                final filteredTraders = _filterTraders(traderProvider.allTraders);
                if (filteredTraders.isEmpty) {
                  return const Center(child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [Icon(Icons.business_off, size: 80, color: Colors.grey), SizedBox(height: 16), Text('لا يوجد تجار', style: TextStyle(fontSize: 18, color: Colors.grey))]));
                }
                return RefreshIndicator(
                  onRefresh: () => traderProvider.loadAllTraders(),
                  child: ListView.builder(
                    padding: const EdgeInsets.all(12),
                    itemCount: filteredTraders.length,
                    itemBuilder: (context, index) => _buildTraderCard(filteredTraders[index]),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildFilterChip(String label, String value, [Color? color]) {
    final isSelected = _selectedFilter == value;
    return FilterChip(label: Text(label), selected: isSelected, onSelected: (selected) => setState(() => _selectedFilter = value), selectedColor: color?.withOpacity(0.3), checkmarkColor: color);
  }

  Widget _buildTraderCard(TraderModel trader) {
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: InkWell(
        onTap: () {},
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [
              CircleAvatar(backgroundColor: _getStatusColor(trader.status).withOpacity(0.2), child: Icon(Icons.business, color: _getStatusColor(trader.status))),
              const SizedBox(width: 12),
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(trader.companyName, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)), const SizedBox(height: 4), Text('نوع النشاط: ${trader.businessType}', style: const TextStyle(color: Colors.grey))])),
              _buildStatusChip(trader.status),
            ]),
            const SizedBox(height: 12),
            Row(children: [_buildInfoItem(Icons.star, 'التقييم', '${trader.rating}'), const SizedBox(width: 16), _buildInfoItem(Icons.shopping_cart, 'المبيعات', '${trader.totalSales}')]),
            if (trader.commercialRegistration != null) Padding(padding: const EdgeInsets.only(top: 8), child: Text('السجل التجاري: ${trader.commercialRegistration}', style: const TextStyle(color: Colors.grey, fontSize: 12))),
            const SizedBox(height: 12),
            Row(mainAxisAlignment: MainAxisAlignment.end, children: [
              if (trader.isPending) ...[
                OutlinedButton.icon(onPressed: () => _handleApproveTrader(trader.id), icon: const Icon(Icons.check, color: Colors.green), label: const Text('قبول'), style: OutlinedButton.styleFrom(foregroundColor: Colors.green)),
                const SizedBox(width: 8),
                OutlinedButton.icon(onPressed: () => _handleRejectTrader(trader.id), icon: const Icon(Icons.close, color: Colors.red), label: const Text('رفض'), style: OutlinedButton.styleFrom(foregroundColor: Colors.red)),
              ],
              if (trader.isApproved) ...[
                OutlinedButton.icon(onPressed: () => _handleSuspendTrader(trader.id), icon: const Icon(Icons.block, color: Colors.orange), label: const Text('تعليق')),
                const SizedBox(width: 8),
                OutlinedButton.icon(onPressed: () => _viewDocuments(trader), icon: const Icon(Icons.description), label: const Text('المستندات')),
              ],
              if (trader.isSuspended) OutlinedButton.icon(onPressed: () => _handleReActivateTrader(trader.id), icon: const Icon(Icons.refresh, color: Colors.green), label: const Text('إعادة تفعيل')),
            ]),
          ]),
        ),
      ),
    );
  }

  Widget _buildInfoItem(IconData icon, String label, String value) => Row(children: [Icon(icon, size: 16, color: Colors.grey), const SizedBox(width: 4), Text('$label: $value', style: const TextStyle(fontSize: 12, color: Colors.grey))]);
  Widget _buildStatusChip(String status) => Chip(label: Text(status == 'pending' ? 'معلق' : status == 'approved' ? 'مقبول' : status == 'rejected' ? 'مرفوض' : status == 'suspended' ? 'موقوف' : status, style: const TextStyle(color: Colors.white, fontSize: 12)), backgroundColor: _getStatusColor(status), padding: EdgeInsets.zero);
  Color _getStatusColor(String status) {
    switch (status) { case 'pending': return Colors.orange; case 'approved': return Colors.green; case 'rejected': return Colors.red; case 'suspended': return Colors.grey; default: return Colors.grey; }
  }

  Future<void> _handleApproveTrader(String traderId) async { await context.read<TraderProvider>().updateTraderStatus(traderId: traderId, status: 'approved'); if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('تم قبول التاجر بنجاح'))); }
  Future<void> _handleRejectTrader(String traderId) async { /* show dialog for reason */ }
  Future<void> _handleSuspendTrader(String traderId) async { await context.read<TraderProvider>().updateTraderStatus(traderId: traderId, status: 'suspended'); }
  Future<void> _handleReActivateTrader(String traderId) async { await context.read<TraderProvider>().updateTraderStatus(traderId: traderId, status: 'approved'); if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('تم إعادة تفعيل التاجر'))); }
  void _viewDocuments(TraderModel trader) {}
}