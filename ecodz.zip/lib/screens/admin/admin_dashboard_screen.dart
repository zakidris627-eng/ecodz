import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:go_router/go_router.dart';
import '../../providers/auth_provider.dart';
import '../../providers/trader_provider.dart';
import '../../providers/order_provider.dart';
import '../../widgets/admin/stat_card.dart';
import '../../widgets/admin/pending_trader_card.dart';

class AdminDashboardScreen extends StatefulWidget {
  const AdminDashboardScreen({super.key});

  @override
  State<AdminDashboardScreen> createState() => _AdminDashboardScreenState();
}

class _AdminDashboardScreenState extends State<AdminDashboardScreen> {
  @override
  void initState() {
    super.initState();
    _loadData();
  }

  Future<void> _loadData() async {
    final traderProvider = context.read<TraderProvider>();
    final orderProvider = context.read<OrderProvider>();

    await Future.wait([
      traderProvider.loadPendingTraders(),
      traderProvider.loadAllTraders(),
      orderProvider.loadAllOrders(),
    ]);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('لوحة تحكم المدير'),
        actions: [
          IconButton(
            icon: const Icon(Icons.notifications),
            onPressed: () => context.push('/admin/notifications'),
          ),
          IconButton(
            icon: const Icon(Icons.settings),
            onPressed: () => context.push('/admin/settings'),
          ),
          PopupMenuButton(
            itemBuilder: (context) => [
              const PopupMenuItem(value: 'logout', child: Text('تسجيل الخروج')),
            ],
            onSelected: (value) async {
              if (value == 'logout') {
                await context.read<AuthProvider>().signOut();
                if (context.mounted) context.go('/login');
              }
            },
          ),
        ],
      ),
      drawer: Drawer(
        child: ListView(
          padding: EdgeInsets.zero,
          children: [
            DrawerHeader(
              decoration: BoxDecoration(color: Theme.of(context).primaryColor),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  CircleAvatar(radius: 30, backgroundColor: Colors.white, child: Icon(Icons.admin_panel_settings, color: Theme.of(context).primaryColor)),
                  const SizedBox(height: 10),
                  const Text('المدير', style: TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold)),
                ],
              ),
            ),
            ListTile(leading: const Icon(Icons.dashboard), title: const Text('الرئيسية'), onTap: () => Navigator.pop(context)),
            ListTile(leading: const Icon(Icons.business), title: const Text('إدارة التجار'), onTap: () { Navigator.pop(context); context.push('/admin/traders'); }),
            ListTile(leading: const Icon(Icons.shopping_cart), title: const Text('الطلبات'), onTap: () { Navigator.pop(context); context.push('/admin/orders'); }),
            ListTile(leading: const Icon(Icons.category), title: const Text('الفئات'), onTap: () { Navigator.pop(context); context.push('/admin/categories'); }),
            const Divider(),
            ListTile(leading: const Icon(Icons.logout, color: Colors.red), title: const Text('تسجيل الخروج', style: TextStyle(color: Colors.red)), onTap: () async {
              await context.read<AuthProvider>().signOut();
              if (context.mounted) context.go('/login');
            }),
          ],
        ),
      ),
      body: RefreshIndicator(
        onRefresh: _loadData,
        child: SingleChildScrollView(
          physics: const AlwaysScrollableScrollPhysics(),
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text('مرحباً بك في لوحة التحكم', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
              const SizedBox(height: 20),
              GridView.count(
                crossAxisCount: 2,
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                crossAxisSpacing: 16,
                mainAxisSpacing: 16,
                children: [
                  StatCard(title: 'التجار النشطين', value: '${context.watch<TraderProvider>().allTraders.where((t) => t.isApproved).length}', icon: Icons.business, color: Colors.green, onTap: () => context.push('/admin/traders')),
                  StatCard(title: 'طلبات معلقة', value: '${context.watch<TraderProvider>().pendingTraders.length}', icon: Icons.pending, color: Colors.orange, onTap: () => context.push('/admin/traders/pending')),
                  StatCard(title: 'إجمالي الطلبات', value: '${context.watch<OrderProvider>().allOrders.length}', icon: Icons.shopping_cart, color: Colors.blue, onTap: () => context.push('/admin/orders')),
                  StatCard(title: 'الإيرادات', value: '\$${_calculateRevenue()}', icon: Icons.monetization_on, color: Colors.purple),
                ],
              ),
              const SizedBox(height: 30),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const Text('طلبات التجار المعلقة', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
                  TextButton(onPressed: () => context.push('/admin/traders/pending'), child: const Text('عرض الكل')),
                ],
              ),
              Consumer<TraderProvider>(
                builder: (context, traderProvider, child) {
                  if (traderProvider.isLoading) return const Center(child: CircularProgressIndicator());
                  if (traderProvider.pendingTraders.isEmpty) return const Card(child: Padding(padding: EdgeInsets.all(20), child: Center(child: Text('لا توجد طلبات معلقة'))));
                  return ListView.builder(
                    shrinkWrap: true,
                    physics: const NeverScrollableScrollPhysics(),
                    itemCount: traderProvider.pendingTraders.length > 3 ? 3 : traderProvider.pendingTraders.length,
                    itemBuilder: (context, index) {
                      final trader = traderProvider.pendingTraders[index];
                      return PendingTraderCard(
                        trader: trader,
                        onApprove: () => _handleApproveTrader(trader.id),
                        onReject: () => _showRejectDialog(trader.id),
                      );
                    },
                  );
                },
              ),
            ],
          ),
        ),
      ),
    );
  }

  String _calculateRevenue() {
    final orders = context.read<OrderProvider>().allOrders;
    final totalCommission = orders.fold<double>(0, (sum, order) => sum + order.commissionAmount);
    return totalCommission.toStringAsFixed(2);
  }

  Future<void> _handleApproveTrader(String traderId) async {
    final traderProvider = context.read<TraderProvider>();
    final success = await traderProvider.updateTraderStatus(traderId: traderId, status: 'approved');
    if (success && mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('تم قبول التاجر بنجاح')));
  }

  Future<void> _showRejectDialog(String traderId) async {
    final reasonController = TextEditingController();
    await showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('رفض التاجر'),
        content: TextField(controller: reasonController, decoration: const InputDecoration(labelText: 'سبب الرفض', border: OutlineInputBorder()), maxLines: 3),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('إلغاء')),
          ElevatedButton(
            onPressed: () async {
              final traderProvider = context.read<TraderProvider>();
              final success = await traderProvider.updateTraderStatus(traderId: traderId, status: 'rejected', rejectionReason: reasonController.text);
              if (success && mounted) { Navigator.pop(context); ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('تم رفض التاجر'))); }
            },
            style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
            child: const Text('رفض'),
          ),
        ],
      ),
    );
  }
}