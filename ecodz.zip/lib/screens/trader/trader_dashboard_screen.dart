import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:go_router/go_router.dart';
import '../../providers/auth_provider.dart';
import '../../providers/product_provider.dart';
import '../../providers/order_provider.dart';
import '../../widgets/trader/order_card.dart';
import '../../widgets/trader/product_card.dart';

class TraderDashboardScreen extends StatefulWidget {
  const TraderDashboardScreen({super.key});
  @override
  State<TraderDashboardScreen> createState() => _TraderDashboardScreenState();
}

class _TraderDashboardScreenState extends State<TraderDashboardScreen> {
  @override
  void initState() {
    super.initState();
    _loadData();
  }

  Future<void> _loadData() async {
    final authProvider = context.read<AuthProvider>();
    if (authProvider.currentUser != null) {
      await Future.wait([
        context.read<ProductProvider>().loadTraderProducts(authProvider.currentUser!.id),
        context.read<OrderProvider>().loadTraderOrders(authProvider.currentUser!.id),
      ]);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('لوحة تحكم التاجر'),
        actions: [
          IconButton(icon: const Icon(Icons.notifications), onPressed: () => context.push('/trader/notifications')),
          IconButton(icon: const Icon(Icons.add), onPressed: () => context.push('/trader/products/add')),
        ],
      ),
      drawer: Drawer(
        child: ListView(
          padding: EdgeInsets.zero,
          children: [
            DrawerHeader(decoration: BoxDecoration(color: Theme.of(context).primaryColor), child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisAlignment: MainAxisAlignment.end, children: [
              CircleAvatar(radius: 30, backgroundColor: Colors.white, child: Icon(Icons.store, color: Theme.of(context).primaryColor)),
              const SizedBox(height: 10),
              Text(context.watch<AuthProvider>().currentUser?.fullName ?? 'تاجر', style: const TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold)),
            ])),
            ListTile(leading: const Icon(Icons.dashboard), title: const Text('الرئيسية'), onTap: () => Navigator.pop(context)),
            ListTile(leading: const Icon(Icons.inventory), title: const Text('منتجاتي'), onTap: () { Navigator.pop(context); context.push('/trader/products'); }),
            ListTile(leading: const Icon(Icons.shopping_cart), title: const Text('الطلبات'), onTap: () { Navigator.pop(context); context.push('/trader/orders'); }),
            const Divider(),
            ListTile(leading: const Icon(Icons.logout, color: Colors.red), title: const Text('تسجيل الخروج', style: TextStyle(color: Colors.red)), onTap: () async { await context.read<AuthProvider>().signOut(); if (mounted) context.go('/login'); }),
          ],
        ),
      ),
      body: RefreshIndicator(
        onRefresh: _loadData,
        child: SingleChildScrollView(
          physics: const AlwaysScrollableScrollPhysics(),
          padding: const EdgeInsets.all(16),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            _buildStatsGrid(),
            const SizedBox(height: 24),
            Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
              const Text('الطلبات الحديثة', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
              TextButton(onPressed: () => context.push('/trader/orders'), child: const Text('عرض الكل')),
            ]),
            Consumer<OrderProvider>(
              builder: (context, orderProvider, child) {
                if (orderProvider.isLoading) return const Center(child: CircularProgressIndicator());
                if (orderProvider.traderOrders.isEmpty) return const Card(child: Padding(padding: EdgeInsets.all(20), child: Center(child: Text('لا توجد طلبات حالياً'))));
                return ListView.builder(
                  shrinkWrap: true, physics: const NeverScrollableScrollPhysics(),
                  itemCount: orderProvider.traderOrders.length > 5 ? 5 : orderProvider.traderOrders.length,
                  itemBuilder: (context, index) => OrderCard(order: orderProvider.traderOrders[index]),
                );
              },
            ),
            const SizedBox(height: 24),
            Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
              const Text('المنتجات', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
              TextButton(onPressed: () => context.push('/trader/products'), child: const Text('إدارة المنتجات')),
            ]),
            Consumer<ProductProvider>(
              builder: (context, productProvider, child) {
                if (productProvider.isLoading) return const Center(child: CircularProgressIndicator());
                if (productProvider.traderProducts.isEmpty) return const Card(child: Padding(padding: EdgeInsets.all(20), child: Center(child: Text('لا توجد منتجات'))));
                return GridView.builder(
                  shrinkWrap: true, physics: const NeverScrollableScrollPhysics(),
                  gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2, crossAxisSpacing: 10, mainAxisSpacing: 10, childAspectRatio: 0.7),
                  itemCount: productProvider.traderProducts.length > 4 ? 4 : productProvider.traderProducts.length,
                  itemBuilder: (context, index) => ProductCard(product: productProvider.traderProducts[index]),
                );
              },
            ),
          ]),
        ),
      ),
      floatingActionButton: FloatingActionButton.extended(onPressed: () => context.push('/trader/products/add'), icon: const Icon(Icons.add), label: const Text('إضافة منتج')),
    );
  }

  Widget _buildStatsGrid() {
    return Consumer2<OrderProvider, ProductProvider>(
      builder: (context, orderProvider, productProvider, child) {
        final activeProducts = productProvider.traderProducts.where((p) => p.isAvailable).length;
        final pendingOrders = orderProvider.traderOrders.where((o) => o.status == 'pending').length;
        final totalRevenue = orderProvider.traderOrders.where((o) => o.status == 'delivered').fold<double>(0, (sum, order) => sum + order.totalAmount);
        return GridView.count(
          crossAxisCount: 2, shrinkWrap: true, physics: const NeverScrollableScrollPhysics(), crossAxisSpacing: 10, mainAxisSpacing: 10,
          children: [
            _buildStatCard('المنتجات النشطة', '$activeProducts', Icons.inventory, Colors.blue),
            _buildStatCard('طلبات معلقة', '$pendingOrders', Icons.pending_actions, Colors.orange),
            _buildStatCard('الإيرادات', '\$${totalRevenue.toStringAsFixed(2)}', Icons.monetization_on, Colors.green),
            _buildStatCard('التقييم', '4.5', Icons.star, Colors.amber),
          ],
        );
      },
    );
  }

  Widget _buildStatCard(String title, String value, IconData icon, Color color) {
    return Card(elevation: 2, child: Padding(padding: const EdgeInsets.all(16), child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
      Icon(icon, size: 30, color: color), const SizedBox(height: 8),
      Text(value, style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: color)),
      const SizedBox(height: 4), Text(title, style: const TextStyle(fontSize: 12, color: Colors.grey), textAlign: TextAlign.center),
    ])));
  }
}