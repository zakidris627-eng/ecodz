import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:provider/provider.dart';
import 'package:go_router/go_router.dart';
import '../../providers/product_provider.dart';
import '../../services/storage_service.dart';

class AddProductScreen extends StatefulWidget {
  const AddProductScreen({super.key});
  @override
  State<AddProductScreen> createState() => _AddProductScreenState();
}

class _AddProductScreenState extends State<AddProductScreen> {
  final _formKey = GlobalKey<FormState>();
  final _nameController = TextEditingController();
  final _descriptionController = TextEditingController();
  final _priceController = TextEditingController();
  final _stockController = TextEditingController();
  final _discountController = TextEditingController();
  String? _selectedCategory;
  List<File> _selectedImages = [];
  bool _isLoading = false;

  Future<void> _pickImages() async {
    final picker = ImagePicker();
    final images = await picker.pickMultiImage(imageQuality: 85, maxWidth: 1024);
    if (images.isNotEmpty) setState(() => _selectedImages.addAll(images.map((e) => File(e.path))));
  }

  Future<void> _submitProduct() async {
    if (!_formKey.currentState!.validate()) return;
    if (_selectedImages.isEmpty) { ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('يرجى إضافة صورة'))); return; }
    setState(() => _isLoading = true);
    try {
      final imageUrls = await StorageService.uploadMultipleImages(_selectedImages, 'products');
      await context.read<ProductProvider>().addProduct(
        name: _nameController.text, description: _descriptionController.text,
        price: double.parse(_priceController.text), stockQuantity: int.parse(_stockController.text),
        categoryId: _selectedCategory!, images: imageUrls,
        discountPercent: _discountController.text.isNotEmpty ? int.parse(_discountController.text) : 0,
      );
      if (mounted) { ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('تم إضافة المنتج بنجاح'))); context.pop(); }
    } catch (e) { if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('خطأ: $e'))); }
    finally { setState(() => _isLoading = false); }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('إضافة منتج جديد')),
      body: SingleChildScrollView(padding: const EdgeInsets.all(16), child: Form(key: _formKey, child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Text('صور المنتج', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
        SizedBox(height: 120, child: ListView.builder(scrollDirection: Axis.horizontal, itemCount: _selectedImages.length + 1, itemBuilder: (context, index) {
          if (index == _selectedImages.length) return GestureDetector(onTap: _pickImages, child: Container(width: 100, margin: const EdgeInsets.only(right: 8), decoration: BoxDecoration(border: Border.all(color: Colors.grey), borderRadius: BorderRadius.circular(8)), child: const Center(child: Icon(Icons.add_photo_alternate, size: 40, color: Colors.grey))));
          return Stack(children: [Container(width: 100, margin: const EdgeInsets.only(right: 8), decoration: BoxDecoration(borderRadius: BorderRadius.circular(8), image: DecorationImage(image: FileImage(_selectedImages[index]), fit: BoxFit.cover))), Positioned(top: 0, right: 0, child: IconButton(icon: const Icon(Icons.close, color: Colors.red), onPressed: () => setState(() => _selectedImages.removeAt(index))))]);
        })),
        const SizedBox(height: 20),
        TextFormField(controller: _nameController, decoration: const InputDecoration(labelText: 'اسم المنتج', border: OutlineInputBorder()), validator: (v) => v == null || v.isEmpty ? 'اسم المنتج مطلوب' : null),
        const SizedBox(height: 16),
        DropdownButtonFormField<String>(value: _selectedCategory, decoration: const InputDecoration(labelText: 'الفئة', border: OutlineInputBorder()), items: const [
          DropdownMenuItem(value: 'electronics', child: Text('إلكترونيات')),
          DropdownMenuItem(value: 'clothing', child: Text('ملابس')),
          DropdownMenuItem(value: 'food', child: Text('طعام')),
        ], onChanged: (v) => setState(() => _selectedCategory = v), validator: (v) => v == null ? 'اختر الفئة' : null),
        const SizedBox(height: 16),
        TextFormField(controller: _descriptionController, decoration: const InputDecoration(labelText: 'الوصف', border: OutlineInputBorder()), maxLines: 3),
        const SizedBox(height: 16),
        Row(children: [
          Expanded(child: TextFormField(controller: _priceController, decoration: const InputDecoration(labelText: 'السعر', border: OutlineInputBorder(), suffixText: 'دج'), keyboardType: TextInputType.number, validator: (v) => v == null || v.isEmpty ? 'مطلوب' : null)),
          const SizedBox(width: 16),
          Expanded(child: TextFormField(controller: _stockController, decoration: const InputDecoration(labelText: 'الكمية', border: OutlineInputBorder()), keyboardType: TextInputType.number, validator: (v) => v == null || v.isEmpty ? 'مطلوب' : null)),
        ]),
        const SizedBox(height: 16),
        TextFormField(controller: _discountController, decoration: const InputDecoration(labelText: 'نسبة الخصم (%)', border: OutlineInputBorder()), keyboardType: TextInputType.number),
        const SizedBox(height: 30),
        SizedBox(width: double.infinity, height: 50, child: ElevatedButton(onPressed: _isLoading ? null : _submitProduct, child: _isLoading ? const CircularProgressIndicator() : const Text('إضافة المنتج', style: TextStyle(fontSize: 18)))),
      ]))),
    );
  }
}