import 'package:flutter/material.dart';
import '../models/product_model.dart';
import '../services/supabase_service.dart';

class ProductProvider extends ChangeNotifier {
  List<ProductModel> _availableProducts = [];
  List<ProductModel> _traderProducts = [];
  bool _isLoading = false;
  String? _error;

  List<ProductModel> get availableProducts => _availableProducts;
  List<ProductModel> get traderProducts => _traderProducts;
  bool get isLoading => _isLoading;
  String? get error => _error;

  Future<void> loadAvailableProducts() async {
    _isLoading = true;
    notifyListeners();
    try {
      final response = await SupabaseService.getProducts();
      _availableProducts = response.map((json) => ProductModel.fromJson(json)).toList();
    } catch (e) {
      _error = e.toString();
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  Future<void> loadTraderProducts(String userId) async {
    _isLoading = true;
    notifyListeners();
    try {
      final traderResponse = await SupabaseService.client
          .from('traders')
          .select('id')
          .eq('user_id', userId)
          .single();
      final traderId = traderResponse['id'];
      final response = await SupabaseService.client
          .from('products')
          .select()
          .eq('trader_id', traderId);
      _traderProducts = response.map((json) => ProductModel.fromJson(json)).toList();
    } catch (e) {
      _error = e.toString();
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  Future<bool> addProduct({
    required String name,
    required String description,
    required double price,
    required int stockQuantity,
    required String categoryId,
    required List<String> images,
    int discountPercent = 0,
    Map<String, String> specifications = const {},
  }) async {
    _isLoading = true;
    _error = null;
    notifyListeners();
    try {
      final user = SupabaseService.client.auth.currentUser;
      if (user == null) throw Exception('User not authenticated');
      final traderResponse = await SupabaseService.client
          .from('traders')
          .select('id')
          .eq('user_id', user.id)
          .single();
      await SupabaseService.client.from('products').insert({
        'trader_id': traderResponse['id'],
        'category_id': categoryId,
        'name': name,
        'description': description,
        'price': price,
        'stock_quantity': stockQuantity,
        'discount_percent': discountPercent,
        'images': images,
        'specifications': specifications,
      });
      await loadTraderProducts(user.id);
      return true;
    } catch (e) {
      _error = e.toString();
      return false;
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  Future<bool> updateProduct({
    required String productId,
    String? name,
    String? description,
    double? price,
    int? stockQuantity,
    int? discountPercent,
    bool? isAvailable,
    List<String>? images,
  }) async {
    try {
      final updates = <String, dynamic>{};
      if (name != null) updates['name'] = name;
      if (description != null) updates['description'] = description;
      if (price != null) updates['price'] = price;
      if (stockQuantity != null) updates['stock_quantity'] = stockQuantity;
      if (discountPercent != null) updates['discount_percent'] = discountPercent;
      if (isAvailable != null) updates['is_available'] = isAvailable;
      if (images != null) updates['images'] = images;
      await SupabaseService.client.from('products').update(updates).eq('id', productId);
      return true;
    } catch (e) {
      _error = e.toString();
      return false;
    }
  }

  Future<bool> deleteProduct(String productId) async {
    try {
      await SupabaseService.client.from('products').delete().eq('id', productId);
      _traderProducts.removeWhere((p) => p.id == productId);
      notifyListeners();
      return true;
    } catch (e) {
      _error = e.toString();
      return false;
    }
  }

  void clearError() {
    _error = null;
    notifyListeners();
  }
}