import 'package:flutter/material.dart';
import '../models/order_model.dart';
import '../services/supabase_service.dart';

class OrderProvider extends ChangeNotifier {
  List<OrderModel> _allOrders = [];
  List<OrderModel> _traderOrders = [];
  List<OrderModel> _customerOrders = [];
  bool _isLoading = false;
  String? _error;

  List<OrderModel> get allOrders => _allOrders;
  List<OrderModel> get traderOrders => _traderOrders;
  List<OrderModel> get customerOrders => _customerOrders;
  bool get isLoading => _isLoading;
  String? get error => _error;

  Future<void> loadAllOrders() async {
    _isLoading = true;
    notifyListeners();
    try {
      final response = await SupabaseService.client
          .from('orders')
          .select('*, order_items(*)')
          .order('created_at', ascending: false);
      _allOrders = response.map((json) => OrderModel.fromJson(json)).toList();
    } catch (e) {
      _error = e.toString();
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  Future<void> loadTraderOrders(String userId) async {
    _isLoading = true;
    notifyListeners();
    try {
      final traderResponse = await SupabaseService.client
          .from('traders')
          .select('id')
          .eq('user_id', userId)
          .single();
      final traderId = traderResponse['id'];
      final response = await SupabaseService.client
          .from('orders')
          .select('*, order_items!inner(*)')
          .filter('order_items.product.trader_id', 'eq', traderId)
          .order('created_at', ascending: false);
      _traderOrders = response.map((json) => OrderModel.fromJson(json)).toList();
    } catch (e) {
      _error = e.toString();
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  Future<void> loadCustomerOrders(String userId) async {
    _isLoading = true;
    notifyListeners();
    try {
      final response = await SupabaseService.client
          .from('orders')
          .select('*, order_items(*)')
          .eq('customer_id', userId)
          .order('created_at', ascending: false);
      _customerOrders = response.map((json) => OrderModel.fromJson(json)).toList();
    } catch (e) {
      _error = e.toString();
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  Future<bool> createOrder({
    required String customerId,
    required List<Map<String, dynamic>> items,
    required double totalAmount,
    required double commissionAmount,
    required Map<String, dynamic> shippingAddress,
    required String paymentMethod,
  }) async {
    _isLoading = true;
    _error = null;
    notifyListeners();
    try {
      final orderNumber = 'ECODZ-${DateTime.now().millisecondsSinceEpoch}';
      final orderResponse = await SupabaseService.client
          .from('orders')
          .insert({
            'customer_id': customerId,
            'order_number': orderNumber,
            'total_amount': totalAmount,
            'commission_amount': commissionAmount,
            'shipping_address': shippingAddress,
            'payment_method': paymentMethod,
          })
          .select()
          .single();
      for (final item in items) {
        await SupabaseService.client.from('order_items').insert({
          'order_id': orderResponse['id'],
          'product_id': item['product_id'],
          'quantity': item['quantity'],
          'unit_price': item['unit_price'],
          'total_price': item['total_price'],
          'commission_rate': item['commission_rate'],
        });
      }
      await loadCustomerOrders(customerId);
      return true;
    } catch (e) {
      _error = e.toString();
      return false;
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  Future<bool> updateOrderStatus({
    required String orderId,
    required String status,
  }) async {
    try {
      await SupabaseService.client
          .from('orders')
          .update({'status': status})
          .eq('id', orderId);
      return true;
    } catch (e) {
      _error = e.toString();
      return false;
    }
  }

  void clearError() {
    _error = null;
    notifyListeners();
  }
}