import 'package:flutter/material.dart';
import '../models/notification_model.dart';
import '../services/supabase_service.dart';

class NotificationProvider extends ChangeNotifier {
  List<NotificationModel> _notifications = [];
  bool _isLoading = false;
  String? _error;
  int _unreadCount = 0;

  List<NotificationModel> get notifications => _notifications;
  bool get isLoading => _isLoading;
  String? get error => _error;
  int get unreadCount => _unreadCount;
  bool get hasUnread => _unreadCount > 0;

  Future<void> loadNotifications(String userId) async {
    _isLoading = true;
    notifyListeners();

    try {
      final response = await SupabaseService.client
          .from('notifications')
          .select()
          .eq('user_id', userId)
          .order('created_at', ascending: false)
          .limit(50);
      
      _notifications = response
          .map((json) => NotificationModel.fromJson(json))
          .toList();
      
      _unreadCount = _notifications.where((n) => !n.isRead).length;
    } catch (e) {
      _error = 'فشل في تحميل الإشعارات';
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  Future<void> markAsRead(String notificationId) async {
    try {
      await SupabaseService.client
          .from('notifications')
          .update({'is_read': true})
          .eq('id', notificationId);
      
      final index = _notifications.indexWhere((n) => n.id == notificationId);
      if (index != -1) {
        _notifications[index] = NotificationModel.fromJson({
          ..._notifications[index].toJson(),
          'is_read': true,
        });
        _unreadCount--;
        notifyListeners();
      }
    } catch (e) {
      debugPrint('Mark as read error: $e');
    }
  }

  Future<void> markAllAsRead(String userId) async {
    try {
      await SupabaseService.client
          .from('notifications')
          .update({'is_read': true})
          .eq('user_id', userId)
          .eq('is_read', false);
      
      _notifications = _notifications.map((n) {
        return NotificationModel.fromJson({
          ...n.toJson(),
          'is_read': true,
        });
      }).toList();
      
      _unreadCount = 0;
      notifyListeners();
    } catch (e) {
      debugPrint('Mark all as read error: $e');
    }
  }

  Future<void> deleteNotification(String notificationId) async {
    try {
      await SupabaseService.client
          .from('notifications')
          .delete()
          .eq('id', notificationId);
      
      _notifications.removeWhere((n) => n.id == notificationId);
      if (!_notifications.any((n) => n.id == notificationId && !n.isRead)) {
        _unreadCount = _notifications.where((n) => !n.isRead).length;
      }
      notifyListeners();
    } catch (e) {
      debugPrint('Delete notification error: $e');
    }
  }

  void clearError() {
    _error = null;
    notifyListeners();
  }
}