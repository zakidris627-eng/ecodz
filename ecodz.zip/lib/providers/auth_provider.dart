import 'package:flutter/material.dart';
import '../models/user_model.dart';
import '../services/supabase_service.dart';

class AuthProvider extends ChangeNotifier {
  UserModel? _currentUser;
  bool _isLoading = false;
  String? _error;

  UserModel? get currentUser => _currentUser;
  bool get isLoading => _isLoading;
  String? get error => _error;
  bool get isAuthenticated => _currentUser != null;
  bool get isAdmin => _currentUser?.isAdmin ?? false;
  bool get isTrader => _currentUser?.isTrader ?? false;
  bool get isCustomer => _currentUser?.isCustomer ?? false;
  String get userId => _currentUser?.id ?? '';
  String get userName => _currentUser?.fullName ?? '';

  Future<void> initialize() async {
    _isLoading = true;
    notifyListeners();
    
    try {
      final userData = await SupabaseService.getCurrentUser();
      if (userData != null) {
        _currentUser = UserModel.fromJson(userData);
      }
    } catch (e) {
      _error = 'فشل في تحميل بيانات المستخدم';
      debugPrint('Auth initialization error: $e');
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  Future<bool> signUp({
    required String email,
    required String password,
    required String fullName,
    required String userType,
    String? phone,
  }) async {
    _isLoading = true;
    _error = null;
    notifyListeners();

    try {
      await SupabaseService.signUp(
        email: email,
        password: password,
        fullName: fullName,
        userType: userType,
        phone: phone,
      );
      return true;
    } catch (e) {
      _error = _getErrorMessage(e.toString());
      return false;
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  Future<bool> signIn({
    required String email,
    required String password,
  }) async {
    _isLoading = true;
    _error = null;
    notifyListeners();

    try {
      await SupabaseService.signIn(
        email: email,
        password: password,
      );
      await initialize();
      return true;
    } catch (e) {
      _error = _getErrorMessage(e.toString());
      return false;
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  Future<void> signOut() async {
    _isLoading = true;
    notifyListeners();
    
    try {
      await SupabaseService.signOut();
      _currentUser = null;
    } catch (e) {
      _error = 'فشل في تسجيل الخروج';
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  Future<bool> updateProfile({
    String? fullName,
    String? phone,
    String? avatarUrl,
  }) async {
    try {
      final updates = <String, dynamic>{};
      if (fullName != null) updates['full_name'] = fullName;
      if (phone != null) updates['phone'] = phone;
      if (avatarUrl != null) updates['avatar_url'] = avatarUrl;

      await SupabaseService.client
          .from('users')
          .update(updates)
          .eq('id', _currentUser!.id);

      await initialize();
      return true;
    } catch (e) {
      _error = 'فشل في تحديث الملف الشخصي';
      return false;
    }
  }

  String _getErrorMessage(String error) {
    if (error.contains('Invalid login credentials')) {
      return 'البريد الإلكتروني أو كلمة المرور غير صحيحة';
    }
    if (error.contains('User already registered')) {
      return 'البريد الإلكتروني مسجل بالفعل';
    }
    if (error.contains('Email not confirmed')) {
      return 'لم يتم تأكيد البريد الإلكتروني';
    }
    return 'حدث خطأ. يرجى المحاولة مرة أخرى';
  }

  void clearError() {
    _error = null;
    notifyListeners();
  }
}