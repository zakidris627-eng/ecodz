import 'package:flutter/material.dart';
import '../models/trader_model.dart';
import '../services/supabase_service.dart';

class TraderProvider extends ChangeNotifier {
  TraderModel? _traderProfile;
  List<TraderModel> _pendingTraders = [];
  List<TraderModel> _allTraders = [];
  bool _isLoading = false;
  String? _error;

  TraderModel? get traderProfile => _traderProfile;
  List<TraderModel> get pendingTraders => _pendingTraders;
  List<TraderModel> get allTraders => _allTraders;
  bool get isLoading => _isLoading;
  String? get error => _error;

  int get pendingCount => _pendingTraders.length;
  int get approvedCount => _allTraders.where((t) => t.isApproved).length;
  int get totalTraders => _allTraders.length;

  Future<void> loadTraderProfile(String userId) async {
    _isLoading = true;
    notifyListeners();

    try {
      final response = await SupabaseService.client
          .from('traders')
          .select()
          .eq('user_id', userId)
          .single();
      
      _traderProfile = TraderModel.fromJson(response);
    } catch (e) {
      _error = 'فشل في تحميل بيانات التاجر';
      debugPrint('Load trader profile error: $e');
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  Future<void> loadPendingTraders() async {
    try {
      final response = await SupabaseService.client
          .from('traders')
          .select('*, users(email, full_name, phone)')
          .eq('status', 'pending')
          .order('created_at', ascending: false);
      
      _pendingTraders = response
          .map((json) => TraderModel.fromJson(json))
          .toList();
      notifyListeners();
    } catch (e) {
      _error = 'فشل في تحميل طلبات التجار';
    }
  }

  Future<void> loadAllTraders() async {
    _isLoading = true;
    notifyListeners();

    try {
      final response = await SupabaseService.client
          .from('traders')
          .select('*, users(email, full_name, phone)')
          .order('created_at', ascending: false);
      
      _allTraders = response
          .map((json) => TraderModel.fromJson(json))
          .toList();
    } catch (e) {
      _error = 'فشل في تحميل قائمة التجار';
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  Future<bool> registerTrader({
    required String userId,
    required String companyName,
    required String commercialRegistration,
    required String taxNumber,
    required String businessType,
    String? description,
  }) async {
    _isLoading = true;
    _error = null;
    notifyListeners();

    try {
      await SupabaseService.client.from('traders').insert({
        'user_id': userId,
        'company_name': companyName,
        'commercial_registration': commercialRegistration,
        'tax_number': taxNumber,
        'business_type': businessType,
        'description': description,
      });
      
      await loadTraderProfile(userId);
      return true;
    } catch (e) {
      _error = 'فشل في تسجيل التاجر';
      return false;
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  Future<bool> updateTraderStatus({
    required String traderId,
    required String status,
    String? rejectionReason,
  }) async {
    _isLoading = true;
    _error = null;
    notifyListeners();

    try {
      final updates = <String, dynamic>{'status': status};
      if (rejectionReason != null) {
        updates['rejection_reason'] = rejectionReason;
      }
      
      await SupabaseService.client
          .from('traders')
          .update(updates)
          .eq('id', traderId);
      
      await Future.wait([
        loadPendingTraders(),
        loadAllTraders(),
      ]);
      
      return true;
    } catch (e) {
      _error = 'فشل في تحديث حالة التاجر';
      return false;
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  Future<bool> uploadVerificationDocuments({
    required String traderId,
    required List<String> documentUrls,
  }) async {
    try {
      final currentDocs = _traderProfile?.verificationDocuments ?? [];
      final newDocs = documentUrls.map((url) => {
        'url': url,
        'uploaded_at': DateTime.now().toIso8601String(),
        'status': 'pending',
      }).toList();
      
      await SupabaseService.client
          .from('traders')
          .update({
            'verification_documents': [...currentDocs, ...newDocs],
          })
          .eq('id', traderId);
      
      if (_traderProfile != null) {
        await loadTraderProfile(_traderProfile!.userId);
      }
      return true;
    } catch (e) {
      _error = 'فشل في رفع المستندات';
      return false;
    }
  }

  void clearError() {
    _error = null;
    notifyListeners();
  }
}