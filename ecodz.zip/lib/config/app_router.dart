import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../screens/splash_screen.dart';
import '../screens/auth/login_screen.dart';
import '../screens/auth/register_screen.dart';
import '../screens/admin/admin_dashboard_screen.dart';
import '../screens/admin/traders_management_screen.dart';
import '../screens/trader/trader_dashboard_screen.dart';
import '../screens/trader/add_product_screen.dart';
import '../screens/customer/customer_home_screen.dart';

class AppRouter {
  static final GoRouter router = GoRouter(
    initialLocation: '/splash',
    debugLogDiagnostics: true,
    
    routes: [
      // Splash Screen
      GoRoute(
        path: '/splash',
        name: 'splash',
        builder: (context, state) => const SplashScreen(),
      ),
      
      // Auth Routes
      GoRoute(
        path: '/login',
        name: 'login',
        builder: (context, state) => const LoginScreen(),
      ),
      GoRoute(
        path: '/register',
        name: 'register',
        builder: (context, state) => const RegisterScreen(),
      ),
      
      // Admin Routes
      GoRoute(
        path: '/admin',
        redirect: (context, state) => '/admin/dashboard',
      ),
      GoRoute(
        path: '/admin/dashboard',
        name: 'adminDashboard',
        builder: (context, state) => const AdminDashboardScreen(),
      ),
      GoRoute(
        path: '/admin/traders',
        name: 'adminTraders',
        builder: (context, state) => const TradersManagementScreen(),
      ),
      GoRoute(
        path: '/admin/traders/pending',
        name: 'adminPendingTraders',
        builder: (context, state) => const TradersManagementScreen(initialFilter: 'pending'),
      ),
      GoRoute(
        path: '/admin/orders',
        name: 'adminOrders',
        builder: (context, state) => const AdminDashboardScreen(),
      ),
      GoRoute(
        path: '/admin/categories',
        name: 'adminCategories',
        builder: (context, state) => const AdminDashboardScreen(),
      ),
      GoRoute(
        path: '/admin/reports',
        name: 'adminReports',
        builder: (context, state) => const AdminDashboardScreen(),
      ),
      GoRoute(
        path: '/admin/users',
        name: 'adminUsers',
        builder: (context, state) => const AdminDashboardScreen(),
      ),
      GoRoute(
        path: '/admin/settings',
        name: 'adminSettings',
        builder: (context, state) => const AdminDashboardScreen(),
      ),
      GoRoute(
        path: '/admin/notifications',
        name: 'adminNotifications',
        builder: (context, state) => const AdminDashboardScreen(),
      ),
      
      // Trader Routes
      GoRoute(
        path: '/trader',
        redirect: (context, state) => '/trader/dashboard',
      ),
      GoRoute(
        path: '/trader/dashboard',
        name: 'traderDashboard',
        builder: (context, state) => const TraderDashboardScreen(),
      ),
      GoRoute(
        path: '/trader/products',
        name: 'traderProducts',
        builder: (context, state) => const TraderDashboardScreen(),
      ),
      GoRoute(
        path: '/trader/products/add',
        name: 'addProduct',
        builder: (context, state) => const AddProductScreen(),
      ),
      GoRoute(
        path: '/trader/orders',
        name: 'traderOrders',
        builder: (context, state) => const TraderDashboardScreen(),
      ),
      GoRoute(
        path: '/trader/reports',
        name: 'traderReports',
        builder: (context, state) => const TraderDashboardScreen(),
      ),
      GoRoute(
        path: '/trader/wallet',
        name: 'traderWallet',
        builder: (context, state) => const TraderDashboardScreen(),
      ),
      GoRoute(
        path: '/trader/settings',
        name: 'traderSettings',
        builder: (context, state) => const TraderDashboardScreen(),
      ),
      GoRoute(
        path: '/trader/notifications',
        name: 'traderNotifications',
        builder: (context, state) => const TraderDashboardScreen(),
      ),
      
      // Customer Routes
      GoRoute(
        path: '/customer',
        redirect: (context, state) => '/customer/home',
      ),
      GoRoute(
        path: '/customer/home',
        name: 'customerHome',
        builder: (context, state) => const CustomerHomeScreen(),
      ),
      GoRoute(
        path: '/customer/cart',
        name: 'customerCart',
        builder: (context, state) => const CustomerHomeScreen(),
      ),
      GoRoute(
        path: '/customer/orders',
        name: 'customerOrders',
        builder: (context, state) => const CustomerHomeScreen(),
      ),
      GoRoute(
        path: '/customer/favorites',
        name: 'customerFavorites',
        builder: (context, state) => const CustomerHomeScreen(),
      ),
      GoRoute(
        path: '/customer/addresses',
        name: 'customerAddresses',
        builder: (context, state) => const CustomerHomeScreen(),
      ),
      GoRoute(
        path: '/customer/settings',
        name: 'customerSettings',
        builder: (context, state) => const CustomerHomeScreen(),
      ),
      GoRoute(
        path: '/customer/notifications',
        name: 'customerNotifications',
        builder: (context, state) => const CustomerHomeScreen(),
      ),
      GoRoute(
        path: '/customer/search',
        name: 'customerSearch',
        builder: (context, state) {
          final query = state.uri.queryParameters['q'] ?? '';
          return CustomerHomeScreen(searchQuery: query);
        },
      ),
      GoRoute(
        path: '/customer/category/:category',
        name: 'customerCategory',
        builder: (context, state) {
          final category = state.pathParameters['category'] ?? '';
          return CustomerHomeScreen(category: category);
        },
      ),
    ],
    
    // Error page
    errorBuilder: (context, state) => Scaffold(
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(Icons.error_outline, size: 80, color: Colors.red),
            const SizedBox(height: 20),
            Text(
              'صفحة غير موجودة',
              style: Theme.of(context).textTheme.headlineSmall,
            ),
            const SizedBox(height: 10),
            Text(state.error.toString()),
          ],
        ),
      ),
    ),
  );
}