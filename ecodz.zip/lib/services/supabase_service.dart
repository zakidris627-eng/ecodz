import 'package:supabase_flutter/supabase_flutter.dart';

class SupabaseService {
  static final SupabaseClient client = Supabase.instance.client;
  
  // ============ Auth Methods ============
  
  static Future<AuthResponse> signUp({
    required String email,
    required String password,
    required String fullName,
    required String userType,
    String? phone,
  }) async {
    final response = await client.auth.signUp(
      email: email,
      password: password,
      data: {
        'full_name': fullName,
        'user_type': userType,
        'phone': phone,
      },
    );
    
    if (response.user != null) {
      await client.from('users').insert({
        'id': response.user!.id,
        'email': email,
        'full_name': fullName,
        'user_type': userType,
        'phone': phone,
      });
    }
    
    return response;
  }
  
  static Future<AuthResponse> signIn({
    required String email,
    required String password,
  }) async {
    return await client.auth.signInWithPassword(
      email: email,
      password: password,
    );
  }
  
  static Future<void> signOut() async {
    await client.auth.signOut();
  }
  
  static Future<void> resetPassword(String email) async {
    await client.auth.resetPasswordForEmail(email);
  }
  
  // ============ User Methods ============
  
  static Future<Map<String, dynamic>?> getCurrentUser() async {
    final user = client.auth.currentUser;
    if (user == null) return null;
    
    final response = await client
        .from('users')
        .select()
        .eq('id', user.id)
        .single();
    
    return response;
  }
  
  static Future<List<Map<String, dynamic>>> getAllUsers() async {
    final response = await client
        .from('users')
        .select()
        .order('created_at', ascending: false);
    
    return response;
  }
  
  // ============ Category Methods ============
  
  static Future<List<Map<String, dynamic>>> getCategories() async {
    final response = await client
        .from('categories')
        .select()
        .eq('is_active', true)
        .order('name');
    
    return response;
  }
  
  static Future<Map<String, dynamic>> getCategoryById(String id) async {
    final response = await client
        .from('categories')
        .select()
        .eq('id', id)
        .single();
    
    return response;
  }
  
  // ============ Product Methods ============
  
  static Future<List<Map<String, dynamic>>> getProducts({
    String? categoryId,
    String? traderId,
    String? searchQuery,
    double? minPrice,
    double? maxPrice,
    int? limit,
    int? offset,
    String sortBy = 'created_at',
    bool ascending = false,
  }) async {
    var query = client.from('products').select('''
      *,
      traders!inner(company_name, rating),
      categories(name_ar),
      reviews(rating)
    ''').eq('is_available', true);
    
    if (categoryId != null) {
      query = query.eq('category_id', categoryId);
    }
    
    if (traderId != null) {
      query = query.eq('trader_id', traderId);
    }
    
    if (searchQuery != null && searchQuery.isNotEmpty) {
      query = query.or('name.ilike.%$searchQuery%,description.ilike.%$searchQuery%');
    }
    
    if (minPrice != null) {
      query = query.gte('price', minPrice);
    }
    
    if (maxPrice != null) {
      query = query.lte('price', maxPrice);
    }
    
    query = query.order(sortBy, ascending: ascending);
    
    if (limit != null) {
      query = query.limit(limit);
    }
    
    if (offset != null) {
      query = query.range(offset, offset + (limit ?? 10) - 1);
    }
    
    return await query;
  }
  
  static Future<Map<String, dynamic>> getProductById(String id) async {
    final response = await client
        .from('products')
        .select('''
          *,
          traders(*),
          categories(*),
          reviews(*)
        ''')
        .eq('id', id)
        .single();
    
    return response;
  }
  
  // ============ Order Methods ============
  
  static Future<String> generateOrderNumber() async {
    final timestamp = DateTime.now().millisecondsSinceEpoch;
    return 'ECODZ-$timestamp';
  }
  
  // ============ Notification Methods ============
  
  static Future<void> sendNotification({
    required String userId,
    required String title,
    required String message,
    required String type,
    Map<String, dynamic>? metadata,
  }) async {
    await client.from('notifications').insert({
      'user_id': userId,
      'title': title,
      'message': message,
      'type': type,
      'metadata': metadata ?? {},
    });
  }
  
  // ============ Settings Methods ============
  
  static Future<Map<String, dynamic>> getSetting(String key) async {
    final response = await client
        .from('system_settings')
        .select('value')
        .eq('key', key)
        .single();
    
    return response['value'];
  }
  
  static Future<double> getCommissionRate() async {
    try {
      final setting = await getSetting('commission_rate');
      return (setting['default'] as num).toDouble();
    } catch (e) {
      return 10.0; // Default commission rate
    }
  }
}