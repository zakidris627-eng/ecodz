import 'dart:io';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:uuid/uuid.dart';

class StorageService {
  static final SupabaseClient client = Supabase.instance.client;
  static const String bucketName = 'ecodz-assets';
  
  // Initialize storage bucket
  static Future<void> initializeBucket() async {
    try {
      await client.storage.createBucket(
        bucketName,
        BucketOptions(public: true),
      );
    } catch (e) {
      // Bucket might already exist
      debugPrint('Bucket initialization: $e');
    }
  }
  
  // Upload single image
  static Future<String> uploadImage(
    File file, 
    String folder, {
    String? fileName,
  }) async {
    try {
      final fileExtension = file.path.split('.').last;
      final name = fileName ?? '${const Uuid().v4()}.$fileExtension';
      final path = '$folder/$name';
      
      await client.storage
          .from(bucketName)
          .upload(path, file);
      
      final imageUrl = client.storage
          .from(bucketName)
          .getPublicUrl(path);
      
      return imageUrl;
    } catch (e) {
      throw Exception('فشل في رفع الصورة: $e');
    }
  }
  
  // Upload multiple images
  static Future<List<String>> uploadMultipleImages(
    List<File> files,
    String folder,
  ) async {
    final urls = <String>[];
    for (final file in files) {
      try {
        final url = await uploadImage(file, folder);
        urls.add(url);
      } catch (e) {
        debugPrint('Error uploading image: $e');
      }
    }
    return urls;
  }
  
  // Delete image
  static Future<void> deleteImage(String imageUrl) async {
    try {
      final uri = Uri.parse(imageUrl);
      final pathSegments = uri.pathSegments;
      final fileName = pathSegments
          .sublist(pathSegments.indexOf(bucketName) + 1)
          .join('/');
      
      await client.storage.from(bucketName).remove([fileName]);
    } catch (e) {
      debugPrint('Error deleting image: $e');
    }
  }
  
  // Delete multiple images
  static Future<void> deleteMultipleImages(List<String> imageUrls) async {
    for (final url in imageUrls) {
      await deleteImage(url);
    }
  }
  
  // Get image URL with transformations (if supported)
  static String getOptimizedImageUrl(String url, {int? width, int? height}) {
    // Supabase image transformations
    if (width != null || height != null) {
      final params = <String>[];
      if (width != null) params.add('width=$width');
      if (height != null) params.add('height=$height');
      return '$url?${params.join('&')}';
    }
    return url;
  }
}