import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class VendorRegistrationScreen extends StatefulWidget {
  const VendorRegistrationScreen({super.key});

  @override
  State<VendorRegistrationScreen> createState() =>
      _VendorRegistrationScreenState();
}

class _VendorRegistrationScreenState extends State<VendorRegistrationScreen> {
  final _formKey = GlobalKey<FormState>();
  final _nameController = TextEditingController();
  final _phoneController = TextEditingController();
  final _registrationNumberController = TextEditingController();

  String? _selectedWilaya;
  File? _kycImage;
  bool _isLoading = false;
  bool _kycEnabled = false; // تفعيل حقل رقم السجل عند رفع صورة

  final supabase = Supabase.instance.client;
  final _picker = ImagePicker();

  // قائمة الولايات الجزائرية
  final List<String> wilayas = const [
    'أدرار',
    'الشلف',
    'الأغواط',
    'أم البواقي',
    'باتنة',
    'بجاية',
    'بسكرة',
    'بشار',
    'البليدة',
    'البويرة',
    'تمنراست',
    'تبسة',
    'تلمسان',
    'تيارت',
    'تيزي وزو',
    'الجزائر',
    'الجلفة',
    'جيجل',
    'سطيف',
    'سعيدة',
    'سكيكدة',
    'سيدي بلعباس',
    'عنابة',
    'قالمة',
    'قسنطينة',
    'المدية',
    'مستغانم',
    'المسيلة',
    'معسكر',
    'ورقلة',
    'وهران',
    'البيض',
    'إليزي',
    'برج بوعريريج',
    'بومرداس',
    'الطارف',
    'تندوف',
    'تيسمسيلت',
    'الوادي',
    'خنشلة',
    'سوق أهراس',
    'تيبازة',
    'ميلة',
    'عين الدفلى',
    'النعامة',
    'عين تيموشنت',
    'غرداية',
    'غليزان',
    'المغير',
    'المنيعة',
    'أولاد جلال',
    'برج باجي مختار',
    'بني عباس',
    'تيميمون',
    'توقرت',
    'جانت',
    'إن صالح',
    'إن قزام',
  ];

  // توليد slug من الاسم
  String _generateSlug(String name) {
    return name
        .trim()
        .toLowerCase()
        .replaceAll(RegExp(r'[^a-z0-9\u0600-\u06FF\s]'), '')
        .replaceAll(RegExp(r'\s+'), '-');
  }

  // رفع الصورة إلى Supabase Storage
  Future<String?> _uploadKycImage(File image) async {
    try {
      final userId = supabase.auth.currentUser!.id;
      final fileName = 'kyc/${userId}_${DateTime.now().millisecondsSinceEpoch}.jpg';
      await supabase.storage.from('kyc_documents').upload(fileName, image);
      final imageUrl = supabase.storage.from('kyc_documents').getPublicUrl(fileName);
      return imageUrl;
    } catch (e) {
      debugPrint('Error uploading KYC: $e');
      return null;
    }
  }

  // اختيار صورة KYC من المعرض
  Future<void> _pickKycImage() async {
    try {
      final picked = await _picker.pickImage(source: ImageSource.gallery);
      if (picked != null) {
        setState(() {
          _kycImage = File(picked.path);
          _kycEnabled = true; // إظهار حقل رقم السجل
        });
      }
    } catch (e) {
      _showSnack('فشل اختيار الصورة');
    }
  }

  // إرسال البيانات إلى Supabase
  Future<void> _submitForm() async {
    if (!_formKey.currentState!.validate()) return;
    if (_kycEnabled && _registrationNumberController.text.trim().isEmpty) {
      _showSnack('يرجى إدخال رقم السجل التجاري / المقاول الذاتي');
      return;
    }

    setState(() => _isLoading = true);

    try {
      final userId = supabase.auth.currentUser!.id;
      final storeName = _nameController.text.trim();
      final slug = _generateSlug(storeName);

      // 1. إدراج المتجر
      final storeResponse = await supabase.from('stores').insert({
        'owner_id': userId,
        'name': storeName,
        'slug': slug,
        'wilaya': _selectedWilaya,
        'phone': _phoneController.text.trim(),
        'status': 'pending', // حالة قيد المراجعة
      }).select('id').single();

      final storeId = storeResponse['id'] as String;

      // 2. رفع وثيقة KYC إن وجدت
      if (_kycImage != null) {
        final imageUrl = await _uploadKycImage(_kycImage!);
        if (imageUrl == null) {
          _showSnack('فشل رفع الوثيقة');
          return;
        }

        await supabase.from('kyc_verifications').insert({
          'store_id': storeId,
          'id_card_image_url': imageUrl,
          'registration_number': _registrationNumberController.text.trim(),
          'status': 'pending',
        });
      }

      // نجاح
      if (!mounted) return;
      _showSnack('تم إرسال طلبك للمراجعة بنجاح', isSuccess: true);
      Navigator.of(context).pop(); // العودة للشاشة السابقة
    } on PostgrestException catch (e) {
      String message = 'حدث خطأ أثناء التسجيل';
      if (e.message.contains('duplicate key')) {
        message = 'اسم المتجر موجود مسبقاً، اختر اسماً آخر';
      }
      _showSnack(message);
    } catch (e) {
      _showSnack('فشل الاتصال، حاول مجدداً');
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  void _showSnack(String message, {bool isSuccess = false}) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: isSuccess ? Colors.green : Colors.redAccent,
        behavior: SnackBarBehavior.floating,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Scaffold(
      backgroundColor: Colors.grey[100],
      appBar: AppBar(
        title: const Text('تسجيل متجر جديد'),
        centerTitle: true,
        elevation: 0,
        backgroundColor: Colors.teal.shade700,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              // بطاقة البيانات الأساسية
              Card(
                elevation: 4,
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(16)),
                child: Padding(
                  padding: const EdgeInsets.all(20),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // اسم المتجر
                      TextFormField(
                        controller: _nameController,
                        textDirection: TextDirection.rtl,
                        decoration: InputDecoration(
                          labelText: 'اسم المتجر *',
                          prefixIcon: const Icon(Icons.store),
                          border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(12)),
                        ),
                        validator: (v) =>
                            v!.trim().isEmpty ? 'مطلوب' : null,
                      ),
                      const SizedBox(height: 16),

                      // الولاية (Dropdown)
                      DropdownButtonFormField<String>(
                        value: _selectedWilaya,
                        decoration: InputDecoration(
                          labelText: 'الولاية *',
                          prefixIcon: const Icon(Icons.location_on),
                          border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(12)),
                        ),
                        items: wilayas.map((w) {
                          return DropdownMenuItem(
                              value: w, child: Text(w, textDirection: TextDirection.rtl));
                        }).toList(),
                        onChanged: (v) => setState(() => _selectedWilaya = v),
                        validator: (v) => v == null ? 'اختر الولاية' : null,
                      ),
                      const SizedBox(height: 16),

                      // رقم الهاتف
                      TextFormField(
                        controller: _phoneController,
                        textDirection: TextDirection.ltr,
                        keyboardType: TextInputType.phone,
                        decoration: InputDecoration(
                          labelText: 'رقم الهاتف *',
                          prefixIcon: const Icon(Icons.phone),
                          hintText: '05xxxxxxxx',
                          border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(12)),
                        ),
                        validator: (v) {
                          if (v!.trim().isEmpty) return 'مطلوب';
                          if (!RegExp(r'^0[5-7]\d{8}$').hasMatch(v.trim()))
                            return 'رقم جزائري غير صحيح';
                          return null;
                        },
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 16),

              // قسم وثيقة KYC (اختياري)
              Card(
                elevation: 4,
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(16)),
                child: Padding(
                  padding: const EdgeInsets.all(20),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Icon(Icons.verified_user,
                              color: Colors.teal.shade700),
                          const SizedBox(width: 8),
                          Text('توثيق الحساب (اختياري)',
                              style: theme.textTheme.titleMedium?.copyWith(
                                  fontWeight: FontWeight.bold)),
                        ],
                      ),
                      const SizedBox(height: 8),
                      Text(
                        'ارفع بطاقة المقاول الذاتي أو السجل التجاري لتسريع قبول متجرك',
                        style: TextStyle(color: Colors.grey[600]),
                      ),
                      const SizedBox(height: 16),

                      // زر رفع الصورة
                      OutlinedButton.icon(
                        onPressed: _pickKycImage,
                        icon: const Icon(Icons.upload_file),
                        label: Text(
                            _kycImage == null ? 'رفع وثيقة' : 'تغيير الوثيقة'),
                        style: OutlinedButton.styleFrom(
                          foregroundColor: Colors.teal.shade700,
                          side: BorderSide(color: Colors.teal.shade200!),
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(12)),
                          padding: const EdgeInsets.symmetric(vertical: 14),
                        ),
                      ),

                      // معاينة الصورة المختارة
                      if (_kycImage != null) ...[
                        const SizedBox(height: 12),
                        ClipRRect(
                          borderRadius: BorderRadius.circular(12),
                          child: Image.file(_kycImage!,
                              height: 120, fit: BoxFit.cover),
                        ),
                        const SizedBox(height: 12),

                        // حقل رقم السجل
                        TextFormField(
                          controller: _registrationNumberController,
                          textDirection: TextDirection.ltr,
                          decoration: InputDecoration(
                            labelText: 'رقم السجل / المقاول الذاتي *',
                            prefixIcon: const Icon(Icons.numbers),
                            border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(12)),
                          ),
                          validator: _kycEnabled
                              ? (v) => v!.trim().isEmpty ? 'مطلوب' : null
                              : null,
                        ),
                      ],
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 24),

              // زر التسجيل
              ElevatedButton(
                onPressed: _isLoading ? null : _submitForm,
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.teal.shade700,
                  foregroundColor: Colors.white,
                  padding: const EdgeInsets.symmetric(vertical: 16),
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12)),
                  textStyle: const TextStyle(
                      fontSize: 18, fontWeight: FontWeight.bold),
                ),
                child: _isLoading
                    ? const SizedBox(
                        height: 24,
                        width: 24,
                        child: CircularProgressIndicator(
                            strokeWidth: 2, color: Colors.white))
                    : const Text('إرسال للمراجعة'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}