import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

// ==============================================
// 1. الدالة الرئيسية وتهيئة Supabase
// ==============================================
void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // استبدل بالقيم الحقيقية من لوحة تحكم Supabase
  await Supabase.initialize(
    url: 'https://vrxjirjjuzwalweaupwm.supabase.co',
    anonKey: 'sb_publishable_8rvLGQZVYi8_Uen-CFboSw_liq6f6b9',
  );

  runApp(const EcoDzApp());
}

// ==============================================
// 2. تطبيق Flutter الأساسي
// ==============================================
class EcoDzApp extends StatelessWidget {
  const EcoDzApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'EcoDz - المتاجر الجزائرية',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primarySwatch: Colors.teal,
        fontFamily: 'Cairo', // يُفضل استخدام خط عربي مثل Cairo
        scaffoldBackgroundColor: Colors.grey[100],
      ),
      home: const AuthGate(),
    );
  }
}

// ==============================================
// 3. بوابة المصادقة: توجيه المستخدم حسب حالة تسجيل الدخول
// ==============================================
class AuthGate extends StatefulWidget {
  const AuthGate({super.key});

  @override
  State<AuthGate> createState() => _AuthGateState();
}

class _AuthGateState extends State<AuthGate> {
  @override
  Widget build(BuildContext context) {
    // الاستماع لتغيرات حالة المصادقة
    return StreamBuilder<AuthState>(
      stream: Supabase.instance.client.auth.onAuthStateChange,
      builder: (context, snapshot) {
        // جلسة المستخدم الحالية
        final session = snapshot.hasData ? snapshot.data!.session : null;

        if (session != null) {
          // مستخدم مسجل الدخول ← الشاشة الرئيسية
          return const HomeScreen();
        } else {
          // لا توجد جلسة ← شاشة تسجيل الدخول
          return const LoginScreen();
        }
      },
    );
  }
}

// ==============================================
// 4. شاشة تسجيل الدخول
// ==============================================
class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _emailController = TextEditingController();
  final _passwordController = TextEditingController();
  bool _isLoading = false;
  String? _errorMessage;

  Future<void> _signIn() async {
    setState(() {
      _isLoading = true;
      _errorMessage = null;
    });

    try {
      await Supabase.instance.client.auth.signInWithPassword(
        email: _emailController.text.trim(),
        password: _passwordController.text.trim(),
      );
      // لا حاجة لشيء هنا؛ AuthGate سيتفاعل مع تغيير الحالة
    } on AuthException catch (e) {
      setState(() => _errorMessage = e.message);
    } catch (e) {
      setState(() => _errorMessage = 'حدث خطأ غير متوقع');
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              // شعار أو اسم التطبيق
              Icon(Icons.storefront_rounded, size: 80, color: Colors.teal.shade700),
              const SizedBox(height: 16),
              Text(
                'EcoDz',
                style: TextStyle(
                  fontSize: 32,
                  fontWeight: FontWeight.bold,
                  color: Colors.teal.shade700,
                ),
              ),
              const SizedBox(height: 8),
              Text(
                'منصة المتاجر الجزائرية',
                style: TextStyle(fontSize: 16, color: Colors.grey[600]),
              ),
              const SizedBox(height: 40),

              // حقل البريد الإلكتروني
              TextField(
                controller: _emailController,
                keyboardType: TextInputType.emailAddress,
                decoration: InputDecoration(
                  labelText: 'البريد الإلكتروني',
                  prefixIcon: const Icon(Icons.email_outlined),
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                ),
              ),
              const SizedBox(height: 16),

              // حقل كلمة المرور
              TextField(
                controller: _passwordController,
                obscureText: true,
                decoration: InputDecoration(
                  labelText: 'كلمة المرور',
                  prefixIcon: const Icon(Icons.lock_outlined),
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                ),
              ),
              const SizedBox(height: 24),

              // رسالة خطأ
              if (_errorMessage != null)
                Padding(
                  padding: const EdgeInsets.only(bottom: 16.0),
                  child: Text(
                    _errorMessage!,
                    style: const TextStyle(color: Colors.red),
                  ),
                ),

              // زر تسجيل الدخول
              SizedBox(
                width: double.infinity,
                height: 50,
                child: ElevatedButton(
                  onPressed: _isLoading ? null : _signIn,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.teal.shade700,
                    foregroundColor: Colors.white,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                  ),
                  child: _isLoading
                      ? const CircularProgressIndicator(color: Colors.white)
                      : const Text('تسجيل الدخول', style: TextStyle(fontSize: 18)),
                ),
              ),
              const SizedBox(height: 16),

              // رابط للتسجيل (يمكن تطويره لاحقاً)
              TextButton(
                onPressed: () {
                  // TODO: الانتقال لشاشة التسجيل
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('ميزة التسجيل قيد التطوير')),
                  );
                },
                child: Text(
                  'ليس لديك حساب؟ سجّل الآن',
                  style: TextStyle(color: Colors.teal.shade600),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ==============================================
// 5. الشاشة الرئيسية (عرض المتاجر المقبولة)
// ==============================================
class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final _supabase = Supabase.instance.client;
  List<Map<String, dynamic>> _stores = [];
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _fetchStores();
  }

  Future<void> _fetchStores() async {
    try {
      setState(() => _isLoading = true);

      final response = await _supabase
          .from('stores')
          .select('*')
          .eq('status', 'approved')
          .order('name');

      setState(() {
        _stores = response as List<Map<String, dynamic>>;
        _isLoading = false;
      });
    } catch (e) {
      debugPrint('Error fetching stores: $e');
      if (mounted) setState(() => _isLoading = false);
    }
  }

  Future<void> _signOut() async {
    await _supabase.auth.signOut();
    // AuthGate سيتعامل مع إعادة التوجيه تلقائياً
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('EcoDz - المتاجر'),
        centerTitle: true,
        backgroundColor: Colors.teal,
        actions: [
          IconButton(
            icon: const Icon(Icons.logout),
            onPressed: _signOut,
            tooltip: 'تسجيل الخروج',
          ),
        ],
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : _stores.isEmpty
              ? const Center(
                  child: Text('لا توجد متاجر متاحة حالياً', style: TextStyle(fontSize: 18)),
                )
              : RefreshIndicator(
                  onRefresh: _fetchStores,
                  child: GridView.builder(
                    padding: const EdgeInsets.all(16),
                    gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: 2,
                      mainAxisSpacing: 12,
                      crossAxisSpacing: 12,
                      childAspectRatio: 0.85,
                    ),
                    itemCount: _stores.length,
                    itemBuilder: (context, index) {
                      final store = _stores[index];
                      return _StoreCard(store: store);
                    },
                  ),
                ),
    );
  }
}

// ==============================================
// 6. بطاقة المتجر (مُعاد استخدامها)
// ==============================================
class _StoreCard extends StatelessWidget {
  final Map<String, dynamic> store;
  const _StoreCard({required this.store});

  @override
  Widget build(BuildContext context) {
    final name = store['name'] ?? 'متجر';
    final wilaya = store['wilaya'] ?? '';
    final logoUrl = store['logo_url'];

    return Card(
      elevation: 4,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      clipBehavior: Clip.antiAlias,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          // صورة الشعار أو حرف أول
          Expanded(
            flex: 3,
            child: Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [Colors.teal.shade200, Colors.teal.shade50],
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                ),
              ),
              child: logoUrl != null && logoUrl.isNotEmpty
                  ? Image.network(logoUrl, fit: BoxFit.contain)
                  : Center(
                      child: CircleAvatar(
                        radius: 36,
                        backgroundColor: Colors.teal.shade400,
                        child: Text(
                          name[0].toUpperCase(),
                          style: const TextStyle(
                            fontSize: 24,
                            fontWeight: FontWeight.bold,
                            color: Colors.white,
                          ),
                        ),
                      ),
                    ),
            ),
          ),
          // معلومات المتجر
          Expanded(
            flex: 2,
            child: Padding(
              padding: const EdgeInsets.all(10),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    name,
                    style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                  const SizedBox(height: 4),
                  Row(
                    children: [
                      Icon(Icons.location_on, size: 14, color: Colors.grey[600]),
                      const SizedBox(width: 2),
                      Expanded(
                        child: Text(
                          wilaya,
                          style: TextStyle(fontSize: 12, color: Colors.grey[600]),
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}