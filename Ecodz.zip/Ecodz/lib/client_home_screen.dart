import 'dart:async';
import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class ClientHomeScreen extends StatefulWidget {
  const ClientHomeScreen({super.key});

  @override
  State<ClientHomeScreen> createState() => _ClientHomeScreenState();
}

class _ClientHomeScreenState extends State<ClientHomeScreen> {
  final supabase = Supabase.instance.client;
  final TextEditingController _searchController = TextEditingController();

  List<Map<String, dynamic>> _stores = [];
  List<String> _wilayas = ['الكل'];
  String? _selectedWilaya;
  bool _isLoading = true;
  Timer? _debounce;

  @override
  void initState() {
    super.initState();
    _fetchWilayas();
    _fetchStores();
    _searchController.addListener(_onSearchChanged);
  }

  @override
  void dispose() {
    _searchController.removeListener(_onSearchChanged);
    _searchController.dispose();
    _debounce?.cancel();
    super.dispose();
  }

  // جلب الولايات المميزة من المتاجر المعتمدة
  Future<void> _fetchWilayas() async {
    try {
      final response = await supabase
          .from('stores')
          .select('wilaya')
          .eq('status', 'approved')
          .order('wilaya');

      final uniqueWilayas = (response as List)
          .map((e) => e['wilaya'] as String)
          .where((w) => w.isNotEmpty)
          .toSet()
          .toList()
        ..sort();
      setState(() {
        _wilayas = ['الكل', ...uniqueWilayas];
      });
    } catch (e) {
      debugPrint('Error fetching wilayas: $e');
    }
  }

  // جلب المتاجر المعتمدة مع مراعاة الفلاتر
  Future<void> _fetchStores() async {
    try {
      setState(() => _isLoading = true);

      var query = supabase
          .from('stores')
          .select('*')
          .eq('status', 'approved')
          .order('name');

      // فلترة بالولاية
      if (_selectedWilaya != null && _selectedWilaya != 'الكل') {
        query = query.eq('wilaya', _selectedWilaya);
      }

      // فلترة بالبحث
      final searchTerm = _searchController.text.trim();
      if (searchTerm.isNotEmpty) {
        query = query.ilike('name', '%$searchTerm%');
      }

      final response = await query;
      setState(() {
        _stores = response as List<Map<String, dynamic>>;
        _isLoading = false;
      });
    } catch (e) {
      setState(() => _isLoading = false);
      debugPrint('Error fetching stores: $e');
    }
  }

  // معالجة تغيير نص البحث مع Debounce
  void _onSearchChanged() {
    _debounce?.cancel();
    _debounce = Timer(const Duration(milliseconds: 500), () {
      _fetchStores();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[100],
      appBar: AppBar(
        title: const Text('المتاجر'),
        centerTitle: true,
        backgroundColor: Colors.teal,
        elevation: 0,
      ),
      body: Column(
        children: [
          // قسم البحث والفلترة
          Container(
            padding: const EdgeInsets.all(16),
            color: Colors.teal.shade700,
            child: Column(
              children: [
                // شريط البحث
                TextField(
                  controller: _searchController,
                  textDirection: TextDirection.rtl,
                  style: const TextStyle(color: Colors.white),
                  decoration: InputDecoration(
                    hintText: 'ابحث عن متجر...',
                    hintStyle: TextStyle(color: Colors.white.withOpacity(0.7)),
                    prefixIcon:
                        const Icon(Icons.search, color: Colors.white),
                    filled: true,
                    fillColor: Colors.white.withOpacity(0.2),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                      borderSide: BorderSide.none,
                    ),
                  ),
                ),
                const SizedBox(height: 12),
                // فلترة الولاية
                Row(
                  children: [
                    const Icon(Icons.location_on,
                        color: Colors.white, size: 20),
                    const SizedBox(width: 8),
                    const Text('الولاية: ',
                        style: TextStyle(color: Colors.white)),
                    Expanded(
                      child: Container(
                        padding: const EdgeInsets.symmetric(horizontal: 8),
                        decoration: BoxDecoration(
                          color: Colors.white.withOpacity(0.2),
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: DropdownButtonHideUnderline(
                          child: DropdownButton<String>(
                            value: _selectedWilaya ?? 'الكل',
                            isExpanded: true,
                            dropdownColor: Colors.teal.shade700,
                            style: const TextStyle(
                                color: Colors.white, fontSize: 14),
                            items: _wilayas.map((w) {
                              return DropdownMenuItem(
                                value: w,
                                child: Text(w,
                                    textDirection: TextDirection.rtl),
                              );
                            }).toList(),
                            onChanged: (val) {
                              setState(() => _selectedWilaya = val);
                              _fetchStores();
                            },
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          // قائمة المتاجر
          Expanded(
            child: _isLoading
                ? const Center(child: CircularProgressIndicator())
                : _stores.isEmpty
                    ? const Center(
                        child: Text('لا توجد متاجر متاحة حالياً',
                            style: TextStyle(fontSize: 18)),
                      )
                    : RefreshIndicator(
                        onRefresh: _fetchStores,
                        child: GridView.builder(
                          padding: const EdgeInsets.all(16),
                          gridDelegate:
                              const SliverGridDelegateWithFixedCrossAxisCount(
                            crossAxisCount: 2,
                            mainAxisSpacing: 12,
                            crossAxisSpacing: 12,
                            childAspectRatio: 0.85,
                          ),
                          itemCount: _stores.length,
                          itemBuilder: (context, index) {
                            final store = _stores[index];
                            return _StoreCard(store: store);
                          },
                        ),
                      ),
          ),
        ],
      ),
    );
  }
}

// بطاقة المتجر
class _StoreCard extends StatelessWidget {
  final Map<String, dynamic> store;

  const _StoreCard({required this.store});

  @override
  Widget build(BuildContext context) {
    final name = store['name'] ?? '';
    final wilaya = store['wilaya'] ?? '';
    final logoUrl = store['logo_url'];

    return GestureDetector(
      onTap: () {
        // يمكنك توجيه المستخدم إلى صفحة المتجر
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('$name قيد التطوير')),
        );
      },
      child: Card(
        elevation: 4,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        clipBehavior: Clip.antiAlias,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            // صورة الشعار
            Expanded(
              flex: 3,
              child: Container(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [
                      Colors.teal.shade200,
                      Colors.teal.shade50,
                    ],
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                  ),
                ),
                child: logoUrl != null && logoUrl.isNotEmpty
                    ? Image.network(
                        logoUrl,
                        fit: BoxFit.contain,
                        errorBuilder: (ctx, err, _) =>
                            _buildDefaultLogo(name),
                      )
                    : _buildDefaultLogo(name),
              ),
            ),
            // معلومات المتجر
            Expanded(
              flex: 2,
              child: Padding(
                padding: const EdgeInsets.all(10),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      name,
                      style: const TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 16,
                      ),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                    const SizedBox(height: 4),
                    Row(
                      children: [
                        Icon(Icons.location_on,
                            size: 14, color: Colors.grey[600]),
                        const SizedBox(width: 2),
                        Expanded(
                          child: Text(
                            wilaya,
                            style: TextStyle(
                              fontSize: 12,
                              color: Colors.grey[600],
                            ),
                            overflow: TextOverflow.ellipsis,
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // شعار افتراضي عند عدم وجود صورة
  Widget _buildDefaultLogo(String name) {
    return Center(
      child: CircleAvatar(
        radius: 36,
        backgroundColor: Colors.teal.shade400,
        child: Text(
          name.isNotEmpty ? name[0].toUpperCase() : 'م',
          style: const TextStyle(
            fontSize: 24,
            fontWeight: FontWeight.bold,
            color: Colors.white,
          ),
        ),
      ),
    );
  }
}