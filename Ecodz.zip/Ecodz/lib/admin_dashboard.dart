import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:url_launcher/url_launcher.dart'; // لعرض الصورة في المتصفح

class AdminDashboardScreen extends StatefulWidget {
  const AdminDashboardScreen({super.key});

  @override
  State<AdminDashboardScreen> createState() => _AdminDashboardScreenState();
}

class _AdminDashboardScreenState extends State<AdminDashboardScreen> {
  final supabase = Supabase.instance.client;
  List<Map<String, dynamic>> _pendingStores = [];
  bool _isLoading = true;
  String? _errorMessage;

  @override
  void initState() {
    super.initState();
    _checkAdminAndFetch();
  }

  // التحقق من أن المستخدم مدير
  Future<void> _checkAdminAndFetch() async {
    try {
      final userId = supabase.auth.currentUser?.id;
      if (userId == null) {
        setState(() {
          _errorMessage = 'يجب تسجيل الدخول';
          _isLoading = false;
        });
        return;
      }

      // جلب دور المستخدم من profiles
      final userData = await supabase
          .from('profiles')
          .select('role')
          .eq('id', userId)
          .maybeSingle();

      if (userData == null || userData['role'] != 'admin') {
        setState(() {
          _errorMessage = 'ليس لديك صلاحية الوصول';
          _isLoading = false;
        });
        return;
      }

      // جلب المتاجر المعلقة
      await _fetchPendingStores();
    } catch (e) {
      setState(() {
        _errorMessage = 'فشل الاتصال';
        _isLoading = false;
      });
    }
  }

  Future<void> _fetchPendingStores() async {
    try {
      setState(() {
        _isLoading = true;
        _errorMessage = null;
      });

      final response = await supabase
          .from('stores')
          .select('*, profiles(full_name), kyc_verifications(*)')
          .eq('status', 'pending')
          .order('created_at', ascending: false);

      setState(() {
        _pendingStores = response as List<Map<String, dynamic>>;
        _isLoading = false;
      });
    } catch (e) {
      setState(() {
        _errorMessage = 'خطأ في تحميل البيانات';
        _isLoading = false;
      });
    }
  }

  // تحديث حالة المتجر و KYC
  Future<void> _updateStoreStatus({
    required String storeId,
    required String newStatus,
    String? reviewerNotes,
  }) async {
    try {
      // تحديث المتجر
      await supabase
          .from('stores')
          .update({'status': newStatus}).eq('id', storeId);

      // تحديث KYC إن وجدت
      final kyc = _pendingStores
          .firstWhere((s) => s['id'] == storeId)['kyc_verifications'];

      if (kyc != null && kyc is Map<String, dynamic>) {
        final kycStatus = newStatus == 'approved' ? 'approved' : 'rejected';
        await supabase
            .from('kyc_verifications')
            .update({
              'status': kycStatus,
              'reviewer_notes': reviewerNotes ?? '',
              'reviewed_at': DateTime.now().toIso8601String(),
            })
            .eq('id', kyc['id']);
      }

      // إعادة تحميل القائمة
      await _fetchPendingStores();

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(newStatus == 'approved'
                ? 'تم قبول المتجر بنجاح'
                : 'تم رفض المتجر'),
            backgroundColor: newStatus == 'approved' ? Colors.green : Colors.red,
          ),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('حدث خطأ أثناء التحديث')),
        );
      }
    }
  }

  // حوار رفض المتجر مع إدخال سبب اختياري
  void _showRejectDialog(String storeId, String storeName) {
    final reasonController = TextEditingController();
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text('رفض متجر "$storeName"'),
        content: TextField(
          controller: reasonController,
          decoration: const InputDecoration(
            hintText: 'سبب الرفض (اختياري)',
            border: OutlineInputBorder(),
          ),
          maxLines: 2,
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('إلغاء'),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(ctx);
              _updateStoreStatus(
                storeId: storeId,
                newStatus: 'rejected',
                reviewerNotes: reasonController.text.trim(),
              );
            },
            style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
            child: const Text('تأكيد الرفض'),
          ),
        ],
      ),
    );
  }

  // فتح صورة KYC في المتصفح
  void _openImage(String? url) {
    if (url != null && url.isNotEmpty) {
      launchUrl(Uri.parse(url), mode: LaunchMode.externalApplication);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[100],
      appBar: AppBar(
        title: const Text('المتاجر قيد المراجعة'),
        backgroundColor: Colors.indigo,
        centerTitle: true,
        elevation: 0,
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : _errorMessage != null
              ? Center(
                  child: Text(
                    _errorMessage!,
                    style: const TextStyle(fontSize: 18, color: Colors.red),
                  ),
                )
              : _pendingStores.isEmpty
                  ? const Center(
                      child: Text(
                        'لا توجد متاجر معلقة حالياً',
                        style: TextStyle(fontSize: 20, color: Colors.grey),
                      ),
                    )
                  : RefreshIndicator(
                      onRefresh: _fetchPendingStores,
                      child: ListView.builder(
                        padding: const EdgeInsets.all(16),
                        itemCount: _pendingStores.length,
                        itemBuilder: (context, index) {
                          final store = _pendingStores[index];
                          final kyc = store['kyc_verifications'] is Map
                              ? store['kyc_verifications']
                              : null;
                          final profile = store['profiles'] is Map
                              ? store['profiles']
                              : null;

                          return Card(
                            margin: const EdgeInsets.only(bottom: 16),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(16),
                            ),
                            elevation: 4,
                            child: Padding(
                              padding: const EdgeInsets.all(16),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  // اسم المتجر
                                  Row(
                                    children: [
                                      Icon(Icons.store,
                                          color: Colors.indigo.shade300),
                                      const SizedBox(width: 8),
                                      Text(
                                        store['name'] ?? '',
                                        style: const TextStyle(
                                          fontSize: 20,
                                          fontWeight: FontWeight.bold,
                                        ),
                                      ),
                                    ],
                                  ),
                                  const SizedBox(height: 12),

                                  // معلومات المتجر
                                  _infoRow(
                                      Icons.person,
                                      'المالك',
                                      profile?['full_name'] ?? 'غير معروف'),
                                  _infoRow(Icons.location_on, 'الولاية',
                                      store['wilaya'] ?? ''),
                                  _infoRow(Icons.phone, 'الهاتف',
                                      store['phone'] ?? 'غير متوفر'),

                                  // بيانات KYC إن وجدت
                                  if (kyc != null) ...[
                                    const Divider(height: 24),
                                    Row(
                                      children: [
                                        Icon(Icons.verified_user,
                                            color: Colors.orange.shade700),
                                        const SizedBox(width: 8),
                                        const Text('وثائق التحقق',
                                            style: TextStyle(
                                                fontWeight: FontWeight.bold)),
                                      ],
                                    ),
                                    const SizedBox(height: 8),
                                    _infoRow(
                                        Icons.credit_card,
                                        'رقم السجل',
                                        kyc['registration_number'] ?? ''),
                                    const SizedBox(height: 8),

                                    // صورة الوثيقة
                                    Row(
                                      children: [
                                        const Icon(Icons.image, size: 20),
                                        const SizedBox(width: 8),
                                        const Text('صورة الوثيقة: '),
                                        GestureDetector(
                                          onTap: () =>
                                              _openImage(kyc['id_card_image_url']),
                                          child: Container(
                                            height: 80,
                                            width: 80,
                                            decoration: BoxDecoration(
                                              borderRadius:
                                                  BorderRadius.circular(12),
                                              border: Border.all(
                                                  color: Colors.grey),
                                              image: DecorationImage(
                                                image: NetworkImage(
                                                    kyc['id_card_image_url']),
                                                fit: BoxFit.cover,
                                              ),
                                            ),
                                          ),
                                        ),
                                        const Spacer(),
                                        TextButton.icon(
                                          onPressed: () =>
                                              _openImage(kyc['id_card_image_url']),
                                          icon: const Icon(Icons.open_in_new,
                                              size: 18),
                                          label: const Text('تكبير'),
                                        ),
                                      ],
                                    ),
                                  ],

                                  const SizedBox(height: 16),

                                  // أزرار الموافقة والرفض
                                  Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceEvenly,
                                    children: [
                                      Expanded(
                                        child: ElevatedButton.icon(
                                          onPressed: () =>
                                              _updateStoreStatus(
                                                  storeId: store['id'],
                                                  newStatus: 'approved'),
                                          icon: const Icon(Icons.check_circle),
                                          label: const Text('موافقة'),
                                          style: ElevatedButton.styleFrom(
                                            backgroundColor: Colors.green,
                                            foregroundColor: Colors.white,
                                            shape:
                                                RoundedRectangleBorder(
                                              borderRadius:
                                                  BorderRadius.circular(12),
                                            ),
                                            padding: const EdgeInsets.symmetric(
                                                vertical: 12),
                                          ),
                                        ),
                                      ),
                                      const SizedBox(width: 12),
                                      Expanded(
                                        child: ElevatedButton.icon(
                                          onPressed: () => _showRejectDialog(
                                              store['id'], store['name']),
                                          icon:
                                              const Icon(Icons.cancel_outlined),
                                          label: const Text('رفض'),
                                          style: ElevatedButton.styleFrom(
                                            backgroundColor: Colors.redAccent,
                                            foregroundColor: Colors.white,
                                            shape:
                                                RoundedRectangleBorder(
                                              borderRadius:
                                                  BorderRadius.circular(12),
                                            ),
                                            padding: const EdgeInsets.symmetric(
                                                vertical: 12),
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ],
                              ),
                            ),
                          );
                        },
                      ),
                    ),
    );
  }

  Widget _infoRow(IconData icon, String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        children: [
          Icon(icon, size: 18, color: Colors.grey[600]),
          const SizedBox(width: 8),
          Text('$label: ', style: const TextStyle(fontWeight: FontWeight.w600)),
          Expanded(child: Text(value)),
        ],
      ),
    );
  }
}